from utils import  AverageMeter,compute_embeddings,manifold_features,mine_cluster_centers_unbalance,load_matfile,get_cluster_metric
from dataset import dataset,modudataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from sklearn import metrics
from deep_clustering_scan import cluster_acc
import argparse
from snr_test import load_model
device='cuda'

P_set=[]
if __name__=='__main__':
    num_class_set=[10,15,20,25,30,35]                
    for num_class in num_class_set:
        model_name='kmeans_ssl_'+str(num_class)+'_.pt'
        model=Transformer_CNN(num_class=12)
        scan_model=SCAN_model(model,num_class).to(device)
        scan_model=load_model(scan_model,name=model_name)
        ##compute features
        batch_size=512
        feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,shuffle=False)
        y_pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),normalize=True,use_last_layers=True)
        P,_,_=get_cluster_metric( y_pred.argmax(1), labels)
        P_set.append(P)
        print ('Pre-trained kmeans purity: {}'.format(P))