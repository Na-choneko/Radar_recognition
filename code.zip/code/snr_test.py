# -*- coding: utf-8 -*-
"""
Created on Sat Sep  3 22:38:07 2022

@author: 29272
"""
import torch
import argparse
from deep_clustering_scan import cluster_acc
from dataset import modudataset,none_transform
from utils import get_cluster_metric,compute_embeddings,load_matfile,match_clusters
from model import CNN,Transformer_CNN,SCAN_model
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
import itertools
from sklearn.metrics import confusion_matrix
def get_params():
    # Training settings
    parser = argparse.ArgumentParser(description='kmeans_ssl')
    parser.add_argument('--lr', type=float, default=1e-4, metavar='LR',
                        help='learning rate ')
    parser.add_argument('--T', type=int, default=0.95, metavar='T',
                        help='psudolabel  threshod')
    args, _ = parser.parse_known_args()
    return args
def load_model(model,name='baseline_cnn.pt'):
   model.load_state_dict(torch.load(name))
   return model
def predicts(dataset_name):
    #make models
    num_class=12
    cnn=CNN(num_class=num_class).cuda()
    transformer_cnn=Transformer_CNN(num_class=num_class).cuda()
    scan_model=SCAN_model(transformer_cnn,num_class).cuda()
    
    #make dataloader
    X,Y=load_matfile(dataset_name)  # batch seq feature
    dataset=modudataset(X,Y,transform=none_transform)
    batch_size=512
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,shuffle=False)
    
    ## inference
    
    model_sup_a=load_model(cnn,name='baseline_cnn_a.pt')
    pred_sup_a,labels=compute_embeddings(dataloader,model_sup_a.eval(),use_last_layers=True)
    
    model_sup=load_model(cnn,name='baseline_cnn.pt')
    pred_sup,labels=compute_embeddings(dataloader,model_sup.eval(),use_last_layers=True)
    
    model_simclr=load_model(transformer_cnn,name='Transformer_cnn_encoder_SimCLR_epoch_799.pt')
    simclr_features,labels=compute_embeddings(dataloader,model_simclr.eval(),normalize=True)
    kmeans = KMeans(n_clusters=num_class, n_init=1000)
    y_pred_simclr = kmeans.fit_predict(simclr_features)
    
    model_scan=load_model(scan_model,name='scan_Transformer_cnn__epoch_29.pt')
    pred_scan,labels=compute_embeddings(dataloader,model_scan.eval(),use_last_layers=True)
    
    model_kmeans_ssl=load_model(scan_model,name='kmeans_ssl.pt')
    pred_kmeans_ssl,labels=compute_embeddings(dataloader,model_kmeans_ssl.eval(),use_last_layers=True)
    return pred_sup_a.argmax(1),pred_sup.argmax(1),y_pred_simclr,pred_scan.argmax(1),pred_kmeans_ssl.argmax(1),labels

def plot_confusion_matrix(predictions, gt, class_names, output_file=None):
    # Plot confusion_matrix and store result to output_file
    predictions=match_clusters(predictions,gt)
    import sklearn.metrics
    import matplotlib.pyplot as plt
    confusion_matrix = sklearn.metrics.confusion_matrix(gt, predictions)
    confusion_matrix = confusion_matrix / np.sum(confusion_matrix, 1)
    
    fig, axes = plt.subplots(1)
    plt.imshow(confusion_matrix, cmap='Blues')
    axes.set_xticks([i for i in range(len(class_names))])
    axes.set_yticks([i for i in range(len(class_names))])
    axes.set_xticklabels(class_names, ha='right', fontsize=8, rotation=40)
    axes.set_yticklabels(class_names, ha='right', fontsize=8)
    
    for (i, j), z in np.ndenumerate(confusion_matrix):
        if i == j:
            axes.text(j, i, '%d' %(100*z), ha='center', va='center', color='white', fontsize=6)
        else:
            pass

    plt.tight_layout()
    if output_file is None:
        plt.figure(dpi=1200)
        plt.show()
    else:
        plt.savefig(output_file, dpi=600, bbox_inches='tight')

if __name__=='__main__':
    num_morto=1
    kmeans_ssl_acc=[]
    kmeans_ssl_P=[]
    kmeans_ssl_nmi=[]
    kmeans_ssl_ari=[]
    
    SimCLR_acc=[]
    SimCLR_P=[]
    SimCLR_nmi=[]
    SimCLR_ari=[]
    
    scan_acc=[]
    scan_P=[]
    scan_nmi=[]
    scan_ari=[]
    
    supervised_acc=[]
    supervised_P=[]
    supervised_nmi=[]
    supervised_ari=[]
    
    a_supervised_acc=[]
    a_supervised_P=[]
    a_supervised_nmi=[]
    a_supervised_ari=[]
    for snr in range(-10,11):
        pred_sup_a,pred_sup,pred_simclr,pred_scan,pred_kmeans_ssl,labels=predicts('test_dataset'+str(snr)+'.mat')
        supervised_acc.append(cluster_acc(pred_sup,labels))
        P,nmi,ari=get_cluster_metric(pred_sup,labels)
        supervised_P.append(P)
        supervised_nmi.append(nmi)
        supervised_ari.append(ari)
        
        a_supervised_acc.append(cluster_acc(pred_sup_a,labels))
        P,nmi,ari=get_cluster_metric(pred_sup_a,labels)
        a_supervised_P.append(P)
        a_supervised_nmi.append(nmi)
        a_supervised_ari.append(ari)
        
        scan_acc.append(cluster_acc(pred_scan,labels))
        P,nmi,ari=get_cluster_metric(pred_scan,labels)
        scan_P.append(P)
        scan_nmi.append(nmi)
        scan_ari.append(ari)
        
        SimCLR_acc.append(cluster_acc(pred_simclr,labels))
        P,nmi,ari=get_cluster_metric(pred_simclr,labels)
        SimCLR_P.append(P)
        SimCLR_nmi.append(nmi)
        SimCLR_ari.append(ari)
        
        kmeans_ssl_acc.append(cluster_acc(pred_kmeans_ssl,labels))
        P,nmi,ari=get_cluster_metric(pred_kmeans_ssl,labels)
        kmeans_ssl_P.append(P)
        kmeans_ssl_nmi.append(nmi)
        kmeans_ssl_ari.append(ari)
    
    # classes=['LFM','NLFM','BPSK' ,'CostasFM','2FSK','4FSK','T1','T2','T3','T4','LFM-2FSK','LFM-BPSK']
    # pred_sup_a,pred_sup,pred_simclr,pred_scan,pred_kmeans_ssl,labels=predicts('train_dataset.mat')
    # plot_confusion_matrix(pred_kmeans_ssl,labels,classes,output_file='kmeans_ssl')
    # plot_confusion_matrix(pred_sup_a,labels,classes,output_file='sup_a')
    # plot_confusion_matrix(pred_simclr,labels,classes,output_file='simclr')
    # plot_confusion_matrix(pred_scan,labels,classes,output_file='scan')