# -*- coding: utf-8 -*-
"""
Created on Sat Sep  3 22:38:07 2022

@author: 29272
"""
import argparse
from kmeans_ssl import kmeans_ssl_main
from deep_clustering_scan import cluster_acc,scan_train_main
from utils import get_cluster_metric
from infogan import infogan_main
from train_ae import AE_main
from train_baseline import train_baseline_main
def get_params():
    # Training settings
    parser = argparse.ArgumentParser(description='kmeans_ssl')
    parser.add_argument('--lr', type=float, default=1e-4, metavar='LR',
                        help='learning rate ')
    parser.add_argument('--T', type=int, default=0.95, metavar='T',
                        help='psudolabel  threshod')
    args, _ = parser.parse_known_args()
    return args

if __name__=='__main__':
    num_morto=6
    kmeans_ssl_acc=[]
    kmeans_ssl_P=[]
    kmeans_ssl_nmi=[]
    kmeans_ssl_ari=[]
    
    SimCLR_acc=[]
    SimCLR_P=[]
    SimCLR_nmi=[]
    SimCLR_ari=[]
    
    scan_acc=[]
    scan_P=[]
    scan_nmi=[]
    scan_ari=[]
    
    
    info_acc=[]
    info_P=[]
    info_nmi=[]
    info_ari=[]
    
    ae_acc=[]
    ae_P=[]
    ae_nmi=[]
    ae_ari=[]
    
    n2d_acc=[]
    n2d_P=[]
    n2d_nmi=[]
    n2d_ari=[]
    
    
    supervised_acc=[]
    supervised_P=[]
    supervised_nmi=[]
    supervised_ari=[]
    
    
    for i in range(num_morto):
        args=vars(get_params())
        # pred,labels=kmeans_ssl_main(args)
        # y_pred=pred.argmax(1)
        # kmeans_ssl_acc.append(cluster_acc(y_pred,labels))
        # P,nmi,ari=get_cluster_metric(y_pred,labels)
        # kmeans_ssl_P.append(P)
        # kmeans_ssl_nmi.append(nmi)
        # kmeans_ssl_ari.append(ari)
        
        pred,labels, y_pred_kmeans=scan_train_main(args)
        y_pred=pred.argmax(1)
        scan_acc.append(cluster_acc(y_pred,labels))
        P,nmi,ari=get_cluster_metric(y_pred,labels)
        scan_P.append(P)
        scan_nmi.append(nmi)
        scan_ari.append(ari)
        
        P,nmi,ari=get_cluster_metric(y_pred_kmeans,labels)
        SimCLR_acc.append(cluster_acc(y_pred_kmeans,labels))
        SimCLR_P.append(P)
        SimCLR_nmi.append(nmi)
        SimCLR_ari.append(ari)
        
        
        # y_pred,labels=infogan_main()
        # info_acc.append(cluster_acc(y_pred,labels))
        # P,nmi,ari=get_cluster_metric(y_pred,labels)
        # info_P.append(P)
        # info_nmi.append(nmi)
        # info_ari.append(ari)
        
        # y_pred,y_pred_n2d,labels=AE_main()
        # ae_acc.append(cluster_acc(y_pred,labels))
        # P,nmi,ari=get_cluster_metric(y_pred,labels)
        # ae_P.append(P)
        # ae_nmi.append(nmi)
        # ae_ari.append(ari)
        
        # n2d_acc.append(cluster_acc(y_pred_n2d,labels))
        # P,nmi,ari=get_cluster_metric(y_pred,labels)
        # n2d_P.append(P)
        # n2d_nmi.append(nmi)
        # n2d_ari.append(ari)        
        
        # y_pred,labels=train_baseline_main()
        # supervised_acc.append(cluster_acc(y_pred,labels))
        # P,nmi,ari=get_cluster_metric(y_pred,labels)
        # supervised_P.append(P)
        # supervised_nmi.append(nmi)
        # supervised_ari.append(ari)
        
        
        
        
        