# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 10:07:16 2022

@author: 29272
"""

from utils import  AverageMeter,compute_embeddings,manifold_features,mine_cluster_centers_unbalance,load_matfile,get_cluster_metric
from dataset import dataset,modudataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt

from deep_clustering_scan import cluster_acc
import argparse
device='cuda'
def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--print_freq', type=int, default=10,
                        help='print frequency')
    parser.add_argument('--save_freq', type=int, default=200,
                        help='save frequency')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='batch_size')
    parser.add_argument('--epochs', type=int, default=500,
                        help='number of training epochs')
    
    # optimization
    parser.add_argument('--learning_rate', type=float, default=5e-4,
                        help='learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-6,
                        help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9,
                        help='momentum')
    # method
    parser.add_argument('--method', type=str, default='SupCon',
                        choices=['SupCon', 'SimCLR'], help='choose method')

    # temperature
    parser.add_argument('--temp', type=float, default=1,
                        help='temperature for loss function')
    opt = parser.parse_args()
    return opt

if __name__=='__main__':
    num_class_set=[35]
    for num_class in num_class_set:
        model=Transformer_CNN(num_class=12)
        state_dict=torch.load('Transformer_cnn_encoder_SimCLR_epoch_799.pt')
        model.load_state_dict(state_dict)
        model=model.to(device).eval()
        ##compute features
        batch_size=512
        feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
        
        features,labels=compute_embeddings(feature_dataloader,model.eval(),normalize=True)
        
        ## kmeans,
        kmeans = KMeans(n_clusters=num_class, n_init=100)
        
        y_pred_kmeans = kmeans.fit_predict(features)
        
        unique,count=np.unique(y_pred_kmeans,return_counts=True)
        P,_,_=get_cluster_metric( y_pred_kmeans, labels)
        print ('Pre-trained kmeans purity: {}'.format(P))
        ratio=0.2
        topk=np.ceil(count*ratio).astype(int)
        cluster_centers=kmeans.cluster_centers_
        ind,purity,distances=mine_cluster_centers_unbalance(features, cluster_centers,topk=topk,labels=labels)
        print (' kmeans nearest_neighbors purity: {}'.format(sum(purity)/len(purity)))
        
        ##### make subdataset using the mined index###########
        X,_=load_matfile('train_dataset.mat')
        labels=[]
        for i in range(num_class):
            labels.append(torch.ones(topk[i],1)*i)
        Y=torch.cat(labels).long()
        index=np.concatenate(ind)
        X=X[index]
        from dataset import train_transform,TwoCropTransform, none_transform
        sub_contrastive_dataset=modudataset(X,Y,transform=TwoCropTransform(train_transform))
        sup_contrastive_dataloader=torch.utils.data.DataLoader(sub_contrastive_dataset,batch_size=batch_size,pin_memory=True,shuffle=True)
        
        from train_contrastive import train
        import torch.optim as optim
        opt=parse_option()
        criterion=SupConLoss(temperature=opt.temp)
        
        model=model.to(device)
        optimizer=optim.SGD(model.parameters(),lr=opt.learning_rate,momentum=opt.momentum)
        for epoch in range(1, opt.epochs + 1):
            loss=train(sup_contrastive_dataloader, model, criterion, optimizer, epoch, opt)
            if (epoch+1)%opt.save_freq==0:
                print(loss)
        print('saving..................')
        torch.save(model.state_dict(),'Transformer_cnn_encoder_'+opt.method+'_epoch_'+str(epoch)+'_num_class_'+str(num_class)+'.pt')
    
    
    
    ## kmeans
    # features,labels=compute_embeddings(feature_dataloader,model.eval())
    
    # kmeans = KMeans(n_clusters=num_class, n_init=20)
    
    # y_pred_kmeans = kmeans.fit_predict(features)

    # print ('supcon kmeans accuracy: {}'.format(cluster_acc( y_pred_kmeans, labels)))
    
    # manifold_features(features,labels,visualize=True)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    