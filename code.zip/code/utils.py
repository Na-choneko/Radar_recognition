
import h5py
import torch
import faiss
import numpy as np
from scipy.optimize import linear_sum_assignment 
from matplotlib import pyplot as plt

def load_matfile(filename):
    '''
    Parameters
    ----------
    filename : matlabfile
        DESCRIPTION.

    Returns
    -------
    TYPE torch.tensor
        return training data with batch seq feature
    TYPE
        return labels

    '''
    dataFile = filename
    mat = h5py.File(dataFile)
    X=mat['X']
    X=X[:]
    Y=mat['Y']
    Y=Y[:]
    return torch.from_numpy(X).float().permute(2,1,0),torch.from_numpy(Y).long().permute(1,0)

def _hungarian_match(flat_preds, flat_targets, preds_k, targets_k):
    # Based on implementation from IIC
    num_samples = flat_targets.shape[0]

    assert (preds_k == targets_k)  # one to one
    num_k = preds_k
    num_correct = np.zeros((num_k, num_k))

    for c1 in range(num_k):
        for c2 in range(num_k):
            # elementwise, so each sample contributes once
            votes = int(((flat_preds == c1) * (flat_targets == c2)).sum())
            num_correct[c1, c2] = votes

    # num_correct is small
    match = linear_sum_assignment(num_samples - num_correct)
    match = np.array(list(zip(*match)))

    # return as list of tuples, out_c to gt_c
    res = []
    for out_c, gt_c in match:
        res.append((out_c, gt_c))

    return res

def match_clusters(y_pred,y_target):
    'match y_pred to y_target'
    match = _hungarian_match(y_pred, y_target, preds_k=12, targets_k=12)
    reordered_preds = np.zeros(len(y_pred))
    for pred_i, target_i in match:
        reordered_preds[y_pred == int(pred_i)] = int(target_i)
    return reordered_preds






def manifold_features(features,labels,method='umap',visualize=False,n_comp=2):
    from sklearn.manifold import TSNE
    from sklearn.decomposition import PCA
    import matplotlib.pyplot as plt
    import umap
    if visualize:
        n_comp=2
        
    if method=='pca':
        reducer=PCA(n_components=n_comp)
    elif method=='tsne':
        reducer=TSNE(n_components=n_comp)
    elif method=='umap':
        reducer=umap.UMAP(densmap=True,n_components=n_comp)
        
    
    t=reducer.fit_transform(features)
    
    if visualize:
        plt.figure(dpi=1200)
        for i in range(len(set(labels))):
            plt.scatter(t[labels==i,0],t[labels==i,1],label='class'+str(i))
        plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.3),
              ncol=3, fancybox=True, shadow=True)
    else:
        return t
    

def compute_embeddings(dataloader,encoder,use_last_layers=False,normalize=False,mode=None):
    embeddings=torch.Tensor()
    labels=torch.Tensor()
    with torch.no_grad():
        for batch in dataloader:
            imgs,label=batch
            imgs=imgs.cuda().squeeze()
            if use_last_layers:
                emb=encoder(imgs)
                normalize=False
            else:
                emb=encoder(imgs,return_feature=True)
            embeddings=torch.cat((embeddings,emb.cpu().squeeze()))
            labels=torch.cat((labels,label.cpu().squeeze()))
    if normalize:
        embeddings=embeddings.transpose(1,0)/embeddings.norm(dim=1)## normalize the features
        return embeddings.transpose(1,0).numpy(),labels.numpy()
    else:
        return embeddings.numpy(),labels.numpy()



class TwoCropTransform:
    """Create two crops datas of the same tranform"""
    def __init__(self, transform):
        self.transform = transform
    def __call__(self, x):
        return [self.transform(x), self.transform(x)]

class TwodifferntTransform:
    """Create two crops of different tranforms"""
    def __init__(self, transform1,transform2):
        self.transform1 = transform1
        self.transform2 = transform2
    def __call__(self, x):
        return [self.transform1(x), self.transform2(x)]


class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count
        
## for SCAN #############

def mine_nearest_neighbors(features, topk=20,labels=None):
    # mine the topk nearest neighbors for every sample
    n, dim = features.shape[0], features.shape[1]
    index = faiss.IndexFlatIP(dim)
    # index = faiss.index_cpu_to_all_gpus(index)
    index.add(features)
    distances, indices = index.search(features, topk+1) # Sample itself is included
    acc=[]
    for i in range(n):
        l=labels[i]
        nearest_index=indices[i,1:topk]
        nearest_labels=labels[nearest_index]
        acc.append(sum(nearest_labels==l)/topk)
    
    return indices,acc

def mine_cluster_centers(features, cluster_centers,topk=20,labels=None):
    # mine the topk nearest neighbors for every sample
    _, dim = features.shape[0], features.shape[1]
    n=cluster_centers.shape[0]
    index = faiss.IndexFlatIP(dim)
    # index = faiss.index_cpu_to_all_gpus(index)
    index.add(features)
    distances, indices = index.search(cluster_centers, topk) # Sample itself is included
    purity=[]
    for i in range(n):
        nearest_index=indices[i,0:topk]
        nearest_labels=labels[nearest_index]
        nearest_labels=nearest_labels.astype(np.int32)
        purity.append(max(np.bincount(nearest_labels))/topk)
    
    return indices,purity,distances

def mine_cluster_centers_unbalance(features, cluster_centers,topk,labels=None):
    # mine the topk nearest neighbors for every sample(consider cluster unbalance)
    _, dim = features.shape[0], features.shape[1]
    n=cluster_centers.shape[0]
    index = faiss.IndexFlatIP(dim)
    # index = faiss.index_cpu_to_all_gpus(index)
    index.add(features)
    distances, indices = index.search(cluster_centers, max(topk).item()) # Sample itself is included
    purity=[]
    indices_set=[]
    for i in range(n):
        nearest_index=indices[i,0:topk[i]]
        indices_set.append(nearest_index)
        nearest_labels=labels[nearest_index]
        nearest_labels=nearest_labels.astype(np.int32)
        purity.append(max(np.bincount(nearest_labels))/topk[i])
    
    return indices_set,purity,distances




def purity_score(y_true, y_pred):
    from sklearn import metrics
    # compute contingency matrix (also called confusion matrix)
    contingency_matrix = metrics.cluster.contingency_matrix(y_true, y_pred)
    # return purity
    return np.sum(np.amax(contingency_matrix, axis=0)) / np.sum(contingency_matrix) 
def get_cluster_metric(pred_label,test_labels):#聚类结果评估
    from sklearn.metrics.cluster import normalized_mutual_info_score as NMI
    from sklearn.metrics import adjusted_rand_score as ARI
    pred_label_without_mask=pred_label.flatten()
    mask_idx=np.argwhere(pred_label_without_mask==-1)
    pred_label_without_mask=np.delete(pred_label_without_mask,mask_idx)
    test_labels_without_mask=test_labels.flatten()
    test_labels_without_mask=np.delete(test_labels_without_mask,mask_idx)
    nmi=NMI(test_labels_without_mask,pred_label_without_mask)
    P=purity_score(test_labels_without_mask,pred_label_without_mask)
    ari=ARI(test_labels_without_mask,pred_label_without_mask)
    return P,nmi,ari

if __name__=='__main__':
    X,Y=load_matfile('train_dataset.mat')