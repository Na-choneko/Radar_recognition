import numpy as np
import torch
import matplotlib.pyplot as plt


class rayleigh_multipath:
    """ a multipath channel with Rayleigh fading  """
    def __init__(self, fs=100e6, N=32,pw=1.0240e-05):
        self.fd=fs/20
        self.fs=fs
        self.N=N
        self.t = np.arange(0, pw, 1/fs) # time vector. (start, stop, step)
        self.x = np.zeros(len(self.t))
        self.y = np.zeros(len(self.t))
        for i in range(N):
            alpha = (np.random.rand() - 0.5) * 2 * np.pi
            phi = (np.random.rand() - 0.5) * 2 * np.pi
            self.x = self.x + np.random.randn() * np.cos(2 * np.pi * self.fd * self.t * np.cos(alpha) + phi)
            self.y = self.y + np.random.randn() * np.sin(2 * np.pi * self.fd * self.t * np.cos(alpha)+ phi)
        # z is the complex coefficient representing channel, you can think of this as a phase shift and magnitude scale
        self.z = (1/np.sqrt(N)) * (self.x + 1j*self.y) # this is what you would actually use when simulating the channel
    def __call__(self,x):
        'apply channel filtering to the input complex signal'
        self.update()
        specx=np.fft.fft(x)
        specx=specx*self.z
        x=np.fft.ifft(specx)
        return x
    def update(self):
        self.fd=self.fs/(10+np.random.rand()*30)
        for i in range(self.N):
            alpha = (np.random.rand() - 0.5) * 2 * np.pi
            phi = (np.random.rand() - 0.5) * 2 * np.pi
            self.x = self.x + np.random.randn() * np.cos(2 * np.pi * self.fd * self.t * np.cos(alpha) + phi)
            self.y = self.y + np.random.randn() * np.sin(2 * np.pi * self.fd * self.t * np.cos(alpha)+ phi)
        # z is the complex coefficient representing channel, you can think of this as a phase shift and magnitude scale
        self.z = (1/np.sqrt(self.N)) * (self.x + 1j*self.y) # this is what you would actually use when simulating the channel
        
        
class rayleigh_multipath_fast:
    """ a multipath channel with Rayleigh fading (tensor) """
    def __init__(self, fs=100e6,N=100,pw=1.0240e-05,device='cpu'):
        self.device=device
        self.fd=fs/20
        self.fs=fs
        self.N=N
        self.t = torch.arange(0, pw, 1/fs).to(device) # time vector. (start, stop, step)
        self.x = torch.zeros(len(self.t)).to(device)
        self.y = torch.zeros(len(self.t)).to(device)
        alpha = (torch.rand(N) - 0.5) * 2 * torch.pi
        alpha=alpha.to(device)
        phi = (torch.rand(N) - 0.5) * 2 * torch.pi
        phi=phi.to(device)
        X=torch.rand(N).to(device) * torch.cos(2 * np.pi * self.fd * self.t.repeat(N,1).transpose(1,0)* torch.cos(alpha) + phi).to(device)
        Y=torch.rand(N).to(device) * torch.sin(2 * np.pi * self.fd * self.t.repeat(N,1).transpose(1,0)* torch.cos(alpha) + phi).to(device)
        self.x=X.sum(1)
        self.y=Y.sum(1)
        self.z = (1/np.sqrt(N)) * (self.x + 1j*self.y) 
        omega_z=(self.z*self.z.conj()).mean()
        self.z=self.z/omega_z.pow(0.5)
    def __call__(self,x):
        'apply channel filtering to the input complex signal'
        self.update()
        specx=torch.fft.fft(x)
        specx=specx*self.z
        x=torch.fft.ifft(specx)
        return x
    def update(self):
        self.fd=self.fs/(10+np.random.rand()*100)
        alpha = (torch.rand(self.N) - 0.5) * 2 * torch.pi
        alpha=alpha.to(self.device)
        phi = (torch.rand(self.N) - 0.5) * 2 * torch.pi
        phi=phi.to(self.device)
        X=torch.rand(self.N).to(self.device) * torch.cos(2 * np.pi * self.fd * self.t.repeat(self.N,1).transpose(1,0)* torch.cos(alpha) + phi).to(self.device)
        Y=torch.rand(self.N).to(self.device) * torch.sin(2 * np.pi * self.fd * self.t.repeat(self.N,1).transpose(1,0)* torch.cos(alpha) + phi).to(self.device)
        self.x=X.sum(1)
        self.y=Y.sum(1)
        self.z = (1/np.sqrt(self.N)) * (self.x + 1j*self.y) 
        omega_z=(self.z*self.z.conj()).mean()
        self.z=self.z/omega_z.pow(0.5)
if __name__=='__main__':
    a=rayleigh_multipath_fast()
# # Simulation Params, feel free to tweak these
# v_mph = 60 # velocity of either TX or RX, in miles per hour
# center_freq = 200e6 # RF carrier frequency in Hz
# Fs = 1e5 # sample rate of simulation
# N = 100 # number of sinusoids to sum

# v = v_mph * 0.44704 # convert to m/s
# fd = v*center_freq/3e8 # max Doppler shift
# print("max Doppler shift:", fd)
# t = np.arange(0, 1, 1/Fs) # time vector. (start, stop, step)
# x = np.zeros(len(t))
# y = np.zeros(len(t))
# for i in range(N):
#     alpha = (np.random.rand() - 0.5) * 2 * np.pi
#     phi = (np.random.rand() - 0.5) * 2 * np.pi
#     x = x + np.random.randn() * np.cos(2 * np.pi * fd * t * np.cos(alpha) + phi)
#     y = y + np.random.randn() * np.sin(2 * np.pi * fd * t * np.cos(alpha) + phi)

# # z is the complex coefficient representing channel, you can think of this as a phase shift and magnitude scale
# z = (1/np.sqrt(N)) * (x + 1j*y) # this is what you would actually use when simulating the channel
# z_mag = np.abs(z) # take magnitude for the sake of plotting
# z_mag_dB = 10*np.log10(z_mag) # convert to dB

# # Plot fading over time
# plt.plot(t, z_mag_dB)
# plt.plot([0, 1], [0, 0], ':r') # 0 dB
# plt.legend(['Rayleigh Fading', 'No Fading'])
# plt.axis([0, 1, -15, 5])
# plt.show()