from utils import  AverageMeter,compute_embeddings,manifold_features,mine_cluster_centers_unbalance,load_matfile,get_cluster_metric
from dataset import dataset,modudataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from sklearn import metrics
from deep_clustering_scan import cluster_acc
import argparse
device='cuda'

if __name__=='__main__':
    max_clusters=20
    s_score=[]
    c_score=[]
    d_score=[]
    
                    
    for num_class in range(max_clusters):
        model=Transformer_CNN(num_class=12)
        state_dict=torch.load('Transformer_cnn_encoder_SimCLR_epoch_799.pt')
        model.load_state_dict(state_dict)
        model=model.to(device).eval()
        ##compute features
        batch_size=512
        feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
        
        features,labels=compute_embeddings(feature_dataloader,model.eval(),normalize=True)
        
        ## kmeans,
        kmeans = KMeans(n_clusters=num_class+2, n_init=1000)
        y_pred_kmeans = kmeans.fit_predict(features)
        unique,count=np.unique(y_pred_kmeans,return_counts=True)
        P,_,_=get_cluster_metric( y_pred_kmeans, labels)
        print ('Pre-trained kmeans purity: {}'.format(P))
        s_score.append(metrics.silhouette_score(features, y_pred_kmeans))
        c_score.append(metrics.calinski_harabasz_score(features, y_pred_kmeans))
        d_score.append(metrics.davies_bouldin_score(features, y_pred_kmeans))