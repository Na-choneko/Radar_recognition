# -*- coding: utf-8 -*-
"""
Created on Tue Aug  9 16:38:50 2022

@author: 29272
"""
import sys
import time
import argparse

from utils import  AverageMeter,compute_embeddings,manifold_features,load_matfile
from dataset import train_dataloader,vali_dataloader,contrastive_dataloader,spec_dataloader
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,RNN_CNN
from losses import SupConLoss
import torch
import torch.optim as optim
from lars import LARS
import torch.nn.functional as F
device='cuda'

def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--print_freq', type=int, default=100,
                        help='print frequency')
    parser.add_argument('--save_freq', type=int, default=200,
                        help='save frequency')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='batch_size')
    parser.add_argument('--epochs', type=int, default=20000,
                        help='number of training epochs')
    
    # optimization
    parser.add_argument('--learning_rate', type=float, default=0.5,
                        help='learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-6,
                        help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9,
                        help='momentum')
    # method
    parser.add_argument('--method', type=str, default='SimCLR',
                        choices=['SupCon', 'SimCLR'], help='choose method')

    # temperature
    parser.add_argument('--temp', type=float, default=1,
                        help='temperature for loss function')
    # model
    parser.add_argument('--model', type=str, default='RNN_CNN',
                        help='model to be use')
    opt = parser.parse_args()
    return opt

def train(train_loader, model, criterion, optimizer, epoch, opt,return_feature=False):
    """one epoch training"""
    from torch.cuda.amp import autocast,GradScaler
    scaler = GradScaler()
    model.train()
    batch_time = AverageMeter()
    data_time = AverageMeter()
    losses = AverageMeter()

    end = time.time()
    for idx, (images, labels) in enumerate(train_loader):
        data_time.update(time.time() - end)

        images = torch.cat([images[0], images[1]], dim=0).squeeze()
        if torch.cuda.is_available():
            images = images.cuda(non_blocking=True)
            labels = labels.cuda(non_blocking=True)
        bsz = labels.shape[0]

        # warm-up learning rate
        #warmup_learning_rate(opt, epoch, idx, len(train_loader), optimizer)

        # compute loss
        with autocast():
            features = model(images,return_feature=return_feature)
            f1, f2 = torch.split(features, [bsz, bsz], dim=0)
            features = torch.cat([f1.unsqueeze(1), f2.unsqueeze(1)], dim=1)
            if opt.method == 'SupCon':
                loss = criterion(features, labels)
            elif opt.method == 'SimCLR':
                loss = criterion(features)
            else:
                raise ValueError('contrastive method not supported: {}'.
                                 format(opt.method))
        
        #print(loss)
        # update metric
        losses.update(loss.item(), bsz)

        # SGD
        optimizer.zero_grad()
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # print info
        if (idx + 1) % opt.print_freq == 0:
            print('Train: [{0}][{1}/{2}]\t'
                  'BT {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'DT {data_time.val:.3f} ({data_time.avg:.3f})\t'
                  'loss {loss.val:.3f} ({loss.avg:.3f})'.format(
                   epoch, idx + 1, len(train_loader), batch_time=batch_time,
                   data_time=data_time, loss=losses))
            sys.stdout.flush()
    return losses.avg
def fine_tune(model,cla,train_dataloader,optimizer,criteria):
    model=model.eval()
    total_loss=0
    c=0
    from torch.cuda.amp import autocast,GradScaler
    scaler = GradScaler()
    for batch in train_dataloader:
        optimizer.zero_grad()###zero the gradient
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        with autocast():
            features=model(x,return_feature=True)
            preds=cla(features)
            loss=criteria(preds, labels)
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
    return total_loss.item()/c
class blank_model(torch.nn.Module):
    def forward(self,x,return_feature=True):
        batch_size=x.size()[0]
        return x.view(batch_size,-1)
        

if __name__=='__main__':
    opt=parse_option()
    criterion=SupConLoss(temperature=opt.temp)
    if opt.model=='CNN':
        model=CNN(num_class=12,base_size=64)
        # state_dict=torch.load('CNN_encoder_SimCLR_epoch_187.pt')
        # model.load_state_dict(state_dict)
    elif opt.model=='Transformer_CNN':
        model=Transformer_CNN(num_class=12)
        # state_dict=torch.load('Transformer_cnn_encoder_SimCLR_epoch_799.pt')
        # model.load_state_dict(state_dict)
    elif opt.model=='RNN_CNN':
        model=RNN_CNN(num_class=12)
        # state_dict=torch.load('RNN_CNN_encoder_SimCLR_epoch_70.pt')
        # model.load_state_dict(state_dict)
    blank_model=blank_model().to(device)
    
    model=model.to(device)
    optimizer=LARS(model.parameters(),lr=opt.learning_rate,momentum=opt.momentum)
    #features,labels=compute_embeddings(train_dataloader,blank_model)
    #manifold_features(features,labels,visualize=True)
    for epoch in range(1, opt.epochs + 1):
        loss=train(contrastive_dataloader, model, criterion, optimizer, epoch, opt)
        if (epoch+1)%opt.save_freq==0:
            print('saving..................')
            torch.save(model.state_dict(),opt.model+'_encoder_'+opt.method+'_epoch_'+str(epoch)+'.pt')
        print(loss)
        
    features,labels=compute_embeddings(vali_dataloader,model)
    manifold_features(features,labels,visualize=True)
    
    
    
    # ####fine tune ###
    from model import LinearClassifier
    criteria=F.cross_entropy
    cla=LinearClassifier(feat_dim=128)
    cla=cla.to(device)
    optimizer=optim.Adam(cla.parameters(),lr=1e-3)
    for epoch in range(1, 1000):
        loss=fine_tune(model,cla,train_dataloader,optimizer,criteria)
        if epoch%10==0:
            print(loss)
    
