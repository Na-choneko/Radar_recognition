# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 10:07:16 2022

@author: 29272
"""

from utils import  AverageMeter,compute_embeddings,manifold_features,mine_cluster_centers,load_matfile,get_cluster_metric
from dataset import dataset,modudataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model,RNN_CNN
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from lars import LARS
from deep_clustering_scan import cluster_acc
import argparse
device='cuda'
def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--print_freq', type=int, default=10,
                        help='print frequency')
    parser.add_argument('--save_freq', type=int, default=200,
                        help='save frequency')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='batch_size')
    parser.add_argument('--epochs', type=int, default=5,
                        help='number of training epochs')
    
    # optimization
    parser.add_argument('--learning_rate', type=float, default=0.1,
                        help='learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-6,
                        help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.9,
                        help='momentum')
    # method
    parser.add_argument('--method', type=str, default='SupCon',
                        choices=['SupCon', 'SimCLR'], help='choose method')

    # temperature
    parser.add_argument('--temp', type=float, default=1,
                        help='temperature for loss function')
    opt = parser.parse_args()
    return opt
num_iter=8
if __name__=='__main__':
    num_class=12
    model_name='RNN_CNN_'
    if model_name=='CNN_':
        model=CNN(num_class=num_class,base_size=64)
        state_dict=torch.load('CNN_encoder_SimCLR_epoch_992.pt')
    if model_name=='Transformer_cnn_':
        model=Transformer_CNN(num_class=num_class)
        state_dict=torch.load('Transformer_cnn_encoder_SimCLR_epoch_799.pt')
    if model_name=='RNN_CNN_':
        model=RNN_CNN(num_class=num_class)
        state_dict=torch.load('RNN_CNN_SupCon_iter_7.pt')
    model.load_state_dict(state_dict)
    model=model.to(device).eval()
    for n_iter in range(num_iter):
        ##compute features
        batch_size=512
        feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
        
        features,labels=compute_embeddings(feature_dataloader,model.eval(),normalize=True)
        
        ## kmeans,
        kmeans = KMeans(n_clusters=num_class, n_init=100)
        
        y_pred_kmeans = kmeans.fit_predict(features)
    
        print ('Pre-trained kmeans accuracy: {}'.format(cluster_acc( y_pred_kmeans, labels)))
        print ('P,nmi air',get_cluster_metric( y_pred_kmeans, labels))
        
        topk=200+n_iter*50
        cluster_centers=kmeans.cluster_centers_
        ind,purity,distances=mine_cluster_centers(features, cluster_centers,topk=topk,labels=labels)
        print (' kmeans nearest_neighbors purity: {}'.format(sum(purity)/len(purity)))
        
        ##### make subdataset using the mined index###########
        X,_=load_matfile('train_dataset.mat')
        labels=[]
        for i in range(num_class):
            labels.append(torch.ones(topk,1)*i)
        Y=torch.cat(labels).long()
        index=ind.flatten()
        X=X[index]
        from dataset import train_transform,TwoCropTransform, none_transform,weak_transform
        sub_contrastive_dataset=modudataset(X,Y,transform=TwoCropTransform(train_transform))
        sup_contrastive_dataloader=torch.utils.data.DataLoader(sub_contrastive_dataset,batch_size=batch_size,pin_memory=True,shuffle=True)
        
        from train_contrastive import train
        import torch.optim as optim
        opt=parse_option()
        criterion=SupConLoss(temperature=opt.temp)
        
        model=model.to(device)
        optimizer=LARS(model.parameters(),lr=opt.learning_rate,momentum=opt.momentum)
        for epoch in range(1, opt.epochs + 1):
            loss=train(sup_contrastive_dataloader, model, criterion, optimizer, epoch, opt)
            # if (epoch+1)%opt.save_freq==0:
            #     print('saving..................')
            #     torch.save(model.state_dict(),model_name+opt.method+'_epoch_'+str(epoch)+'.pt')
            print(loss)
        torch.save(model.state_dict(),model_name+opt.method+'_iter_'+str(n_iter)+'.pt')
        
        
        ## kmeans
        # features,labels=compute_embeddings(feature_dataloader,model.eval())
        
        # kmeans = KMeans(n_clusters=num_class, n_init=100)
        
        # y_pred_kmeans = kmeans.fit_predict(features)
    
        # print ('supcon kmeans accuracy: {}'.format(cluster_acc( y_pred_kmeans, labels)))
        
       # manifold_features(features,labels,visualize=True)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    