# -*- coding: utf-8 -*-
"""
Created on Wed Aug 24 10:23:46 2022

@author: 29272
"""
from utils import  AverageMeter,compute_embeddings,manifold_features,mine_nearest_neighbors,mine_cluster_centers
from dataset import dataset,train_dataloader,vali_dataloader,contrastive_dataloader,spec_dataloader
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
import argparse

def get_params():
    # Training settings
    parser = argparse.ArgumentParser(description='scan')
    parser.add_argument('--lr', type=float, default=1e-3, metavar='LR',
                        help='learning rate (default: 1e-3)')
    parser.add_argument('--T', type=int, default=0.95, metavar='T',
                        help='psudolabel  threshod')
    args, _ = parser.parse_known_args()
    return args
def cluster_acc(y_pred, y_target):
    D = max(int(y_pred.max()), int(y_target.max())) + 1#num of classes
    w = np.zeros((D, D), dtype=np.int64)# init the assignment matrix
    for i in range(y_pred.size):
        w[int(y_pred[i]), int(y_target[i])] += 1

    row_ind, col_ind = linear_assignment(w.max() - w)
    return w[row_ind, col_ind].sum()/y_pred.size

def scan_train(train_loader, model, criterion, optimizer, epoch, device):
    """ 
    Train w/ SCAN-Loss
    """

    model.train() # Update BN
    
    start = time.time()
    total_loss_lst = []
    consistency_loss_lst = []
    entropy_loss_lst = []
    for i, batch in enumerate(train_loader):
        # Forward pass
        anchors = batch['anchor'].to(device).squeeze()
        neighbors = batch['neighbor'].to(device).squeeze()
      
        # Calculate gradient for backprop of complete network
        anchors_output = model(anchors)
        neighbors_output = model(neighbors)    
        # Loss for every head
        total_loss, consistency_loss, entropy_loss = [], [], []
        total_loss_, consistency_loss_, entropy_loss_ = criterion(anchors_output,
                                                                     neighbors_output)
        total_loss.append(total_loss_)
        consistency_loss.append(consistency_loss_)
        entropy_loss.append(entropy_loss_)
        loss = torch.sum(torch.stack(total_loss, dim=0))

        optimizer.zero_grad()
        loss.backward()

        optimizer.step()
        tmp1 = np.mean([v.item() for v in total_loss])
        tmp2 = np.mean([v.item() for v in consistency_loss])
        tmp3 = np.mean([v.item() for v in entropy_loss])
        total_loss_lst.append(tmp1)
        consistency_loss_lst.append(tmp2)
        entropy_loss_lst.append(tmp3)


        if i % (len(train_loader) // 10) == 0:
            now = time.time()
            time_used = int(now - start)
            print('time_used',time_used)
            print('total_loss',tmp1)
            print('consistency',tmp2)
            print('entropy',tmp3)

    end = time.time()
    time_used = int(end - start)

def scan_train_main(args):
    # model=CNN(num_class=12)
    # state_dict=torch.load('CNN_encoder_SimCLR_epoch_1451.pt')
    
    model=Transformer_CNN(num_class=12)
    state_dict=torch.load('Transformer_cnn_encoder_SimCLR_epoch_62.pt')
    model.load_state_dict(state_dict)
    model=model.to(device).eval()
    ##compute features
    batch_size=512
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
    
    features,labels=compute_embeddings(feature_dataloader,model.eval(),normalize=True)
    #features=manifold_features(features,labels,n_comp=3,method='umap')
    
    ## kmeans
    kmeans = KMeans(n_clusters=12, n_init=100)
    
    y_pred_kmeans = kmeans.fit_predict(features)    
    ## SCAN
    indices,acc=mine_nearest_neighbors(features,topk=50,labels=labels)
    print('nearest_neighbors accuracy:{}'.format(sum(acc)/len(acc)))
    

    
    ########train SCAN ###################
    from dataset import base_dataset,ScanData,train_transform,T
    from losses import SCANLoss
    scan_dataset = ScanData(base_dataset, indices, train_transform)
    scan_data_loader = DataLoader(scan_dataset, batch_size=batch_size, shuffle=True)
    # batch=next(iter(scan_data_loader))
    # X0=batch['anchor']
    # X1=batch['neighbor']
    # plt.figure()
    # plt.imshow(T.spectrumgram(T.change_order(X0[1])),cmap='gray')
    # plt.figure()
    # plt.imshow(T.spectrumgram(T.change_order(X1[1])),cmap='gray') 
    #next(iter(scan_dataset))
    
    
    criterion = SCANLoss(5)
    scan_model=SCAN_model(model,12).to(device)
    optimizer = torch.optim.Adam(scan_model.parameters(), lr=2e-4, weight_decay=0)
    
    for epoch in range(30):
        scan_train(scan_data_loader, scan_model, criterion, optimizer, epoch, device)
    
    pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True)
    
    print('saving..................')
    torch.save(scan_model.state_dict(),'scan_Transformer_cnn_'+'_epoch_'+str(epoch)+'.pt')
    return pred,labels, y_pred_kmeans
device='cuda'
if __name__=='__main__':
    args=vars(get_params())
    scan_train_main(args)

    
    
    