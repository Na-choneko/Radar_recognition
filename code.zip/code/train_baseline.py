# -*- coding: utf-8 -*-
"""
Created on Mon Aug  8 16:52:44 2022

@author: 29272
"""
from dataset import train_dataloader,vali_dataloader,test_dataloader,spec_dataloader,weak_transform,none_transform
from deep_clustering_scan import cluster_acc
from utils import  compute_embeddings,get_cluster_metric
from model import MatchboxNet,CNN,CNN_spec,RNN_CNN
import torch
import torch.optim as optim
import torch.nn.functional as F
from torch.cuda.amp import autocast,GradScaler
device='cuda'
scaler = GradScaler()


def train_on_epoch(model,train_dataloader,optimizer,criteria):
    model.train()
    total_loss=0
    c=0
    for batch in train_dataloader:
        optimizer.zero_grad()###zero the gradient
        
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        with autocast():
            preds=model(x)
            loss=criteria(preds, labels)
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
    return total_loss.item()/c
def train_baseline_main():
    model=CNN(num_class=12)
    # state_dict=torch.load('baseline_cnn.pt')
    # model.load_state_dict(state_dict)
    model=model.to(device)
    optimizer=optim.Adam(model.parameters(),lr=1e-3)
    criteria=F.cross_entropy
    last_acc=0
    c=0
    for epoch in range(1000):
        loss=train_on_epoch(model,train_dataloader,optimizer,criteria)
        if epoch%5==0:
            vali_dataloader.dataset.transform=none_transform
            pred,labels=compute_embeddings(vali_dataloader,model.eval(),use_last_layers=True)
            acc=cluster_acc(pred.argmax(1),labels)
            vali_dataloader.dataset.transform=none_transform
            if acc>last_acc:
                last_acc=acc
                c=0
                print('saving..................')
                torch.save(model.state_dict(),'baseline_cnn'+'.pt')
            else:
                c+=1
            if c>=50:
                break
            print(loss)
            print(acc)
    vali_dataloader.dataset.transform=none_transform
    pred,labels=compute_embeddings(test_dataloader,model.eval(),use_last_layers=True)
    return pred.argmax(1),labels

if __name__=='__main__':
    B=6
    R=1 
    C=128
    pred,labels=train_baseline_main()
    #model=MatchboxNet(B, R, C, kernel_sizes=[5,5,5,3,3,3],inter_feature_dim=C, NUM_CLASSES=7)
    
    
    
    
    