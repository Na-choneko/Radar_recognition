# -*- coding: utf-8 -*-

from utils import compute_embeddings,manifold_features,mine_cluster_centers,load_matfile,get_cluster_metric,mine_cluster_centers_unbalance
from dataset import dataset,modudataset
from model import CNN,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt

from deep_clustering_scan import cluster_acc
import argparse
import torch.optim as optim
import torch.nn.functional as F
from torch.cuda.amp import autocast,GradScaler

from torch.utils.tensorboard import SummaryWriter
logger = SummaryWriter('./log')
device='cuda'
scaler = GradScaler()

def get_params(num_class=12):
    # Training settings
    parser = argparse.ArgumentParser(description='kmeans_ssl')
    parser.add_argument('--lr', type=float, default=2e-4, metavar='LR',
                        help='learning rate (default: 1e-3)')
    parser.add_argument('--T', type=int, default=0.9, metavar='T',
                        help='psudolabel  threshod')
    parser.add_argument('--num_class', type=int, default=num_class, metavar='C',
                        help='num_classes')
    args, _ = parser.parse_known_args()
    return args

def train_ssl(model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch,update_head_only=False):
    model.train()
    if update_head_only:
        model.backbone.eval()
    total_loss=0
    c=0
    weak_anchors_collector=[]
    weight_per_class=None
    worm_up_epoch=50
    for batch in sup_dataloader:
        optimizer.zero_grad()###zero the gradient
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        #lambda_u=(1-np.exp(-(epoch-worm_up_epoch)/1000))*10
        lambda_u=1
        if epoch>=worm_up_epoch:## warm up
            u_batch=next(iter(unsup_dataloader))
            x_u = u_batch['weak'].to(device).squeeze()
            x_u_augmented = u_batch['strong'].to(device).squeeze()
        
        
        with autocast():
            if epoch>=worm_up_epoch:
            ### unsupervised loss
                with torch.no_grad():
                    output_u = model(x_u)
                    weak_anchors_collector.append(output_u)
                output_u_augmented = model(x_u_augmented)
                loss_u,thresholds,target = criteria_unsup(output_u, output_u_augmented,weight_per_class)
                
            else:
                loss_u=0
            ### supervised loss
            preds=model(x)
            loss_sup=criteria_sup(preds, labels)
            if epoch>=worm_up_epoch:
                loss=loss_sup+lambda_u*loss_u
            else:
                loss=loss_sup
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
        # logger.add_scalar('norm_1', model.head[0].weight.grad.norm(), c)
        # logger.add_scalar('norm_2', model.backbone.layer1[0].weight.grad.norm(), c)
    if epoch>=worm_up_epoch:
        weak_anchors_collector=torch.cat(weak_anchors_collector)
        weight_per_class=criteria_unsup.compute_class_weight(weak_anchors_collector)
        # tensorboard logger
        logger.add_scalar('loss_u', loss_u, epoch)
        logger.add_scalar('loss_sup', loss_sup, epoch)
        logger.add_histogram('weight_per_class', weight_per_class, epoch)
        
        # adjust threshod
        current_threshold=criteria_unsup.threshold
        criteria_unsup.threshold=current_threshold+(0.99-current_threshold)/100
        #print(current_threshold)
        # print(target)
    return total_loss.item()/c

def kmeans_ssl_main(args):
    num_class=args['num_class']
    # model=CNN(num_class=num_class)
    # state_dict=torch.load('CNN_encoder_SimCLR_epoch_1451.pt')
    model=Transformer_CNN(num_class=12)
    model_name='Transformer_cnn_encoder_SupCon_epoch_500_num_class_'+str(num_class)+'.pt'
    state_dict=torch.load(model_name)
    model.load_state_dict(state_dict)
    model=model.to(device).eval()
    ##compute features
    batch_size=512
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
    
    features,labels=compute_embeddings(feature_dataloader,model,normalize=True)
    #features=manifold_features(features,labels,n_comp=3,method='umap')
    
    ## kmeans
    kmeans = KMeans(n_clusters=num_class, n_init=100)
    
    y_pred_kmeans = kmeans.fit_predict(features)
    
    unique,count=np.unique(y_pred_kmeans,return_counts=True)
    P,_,_=get_cluster_metric( y_pred_kmeans, labels)
    print ('Pre-trained kmeans purity: {}'.format(P))
    
    
    ratio=0.3
    topk=np.ceil(count*ratio).astype(int)
    cluster_centers=kmeans.cluster_centers_
    ind,purity,distances=mine_cluster_centers_unbalance(features, cluster_centers,topk=topk,labels=labels)
    print (' kmeans nearest_neighbors purity: {}'.format(sum(purity)/len(purity)))
    
    ##### make subdataset using the mined index###########
    X,_=load_matfile('train_dataset.mat')
    labels=[]
    for i in range(num_class):
        labels.append(torch.ones(topk[i],1)*i)
    Y=torch.cat(labels).long()
    index=np.concatenate(ind)
    u_index=np.setdiff1d(np.arange(0,len(X),1),index)
    X=X[index]
    from dataset import train_transform, none_transform,SelfLabelData,train_transform,weak_transform,base_dataset
    from losses import ConfidenceBasedCE,FlexMatchLoss
    unsup_dataset=torch.utils.data.Subset(base_dataset,u_index)
    unsup_dataset=SelfLabelData(unsup_dataset, weak_transform, train_transform)
    unsup_dataloader=torch.utils.data.DataLoader(unsup_dataset,batch_size=batch_size,shuffle=True)
    criteria_unsup = FlexMatchLoss(args['T'])
    
    sup_dataset=modudataset(X,Y,transform=train_transform)
    sup_dataloader=torch.utils.data.DataLoader(sup_dataset,batch_size=batch_size,shuffle=True)
    criteria_sup=F.cross_entropy
    
    scan_model=SCAN_model(model,num_class).to(device)
    optimizer=optim.Adam(scan_model.parameters(),lr=args['lr'])
     
    
    for epoch in range(300):
      loss=train_ssl(scan_model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch)
      print(loss)
      if epoch%5==0:
          pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True)
          P,_,_=get_cluster_metric( pred.argmax(1), labels)
          print ('purity: {}'.format(P))
          logger.add_scalar('Purity', P, epoch)
      
    pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True)
    print('saving..................')
    torch.save(scan_model.state_dict(),'kmeans_ssl_'+str(num_class)+'_.pt')
    return pred,labels



if __name__=='__main__':
    num_class_set=[35]
    for num_class in num_class_set:
        args=vars(get_params(num_class))
        pred,labels=kmeans_ssl_main(args)
        print ('accuracy: {}'.format(cluster_acc( pred.argmax(1), labels)))

