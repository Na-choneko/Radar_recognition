# -*- coding: utf-8 -*-
"""
Created on Fri Sep  2 15:52:43 2022

@author: 29272
"""
import argparse
import logging
import nni
from nni.utils import merge_parameter
from kmeans_ssl import kmeans_ssl_main,get_params
from deep_clustering_scan import cluster_acc
logger = logging.getLogger('kmeans_ssl')

if __name__=='__main__':
    try:
        # get parameters form tuner
        tuner_params = nni.get_next_parameter()
        logger.debug(tuner_params)
        params = vars(merge_parameter(get_params(), tuner_params))
        print(params)
        pred,labels=kmeans_ssl_main(params)
        y_pred=pred.argmax(1)
        cluster_acc=cluster_acc(y_pred,labels)
        # report final result
        nni.report_final_result(cluster_acc)
        logger.debug('Final result is %g', cluster_acc)
        logger.debug('Send final result done.')
    except Exception as exception:
        logger.exception(exception)
        raise