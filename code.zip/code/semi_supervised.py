# -*- coding: utf-8 -*-
from kmeans_ssl import *
from model import RNN_CNN
from dataset import train_transform, none_transform,SelfLabelData,train_transform,weak_transform,base_dataset,split_dataset
from losses import ConfidenceBasedCE,FlexMatchLoss
def load_model(model,name='baseline_cnn.pt'):
   model.load_state_dict(torch.load(name))
   return model
def train_ssl(model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch,update_head_only=False):
    model.train()
    if update_head_only:
        for param in model.backbone.parameters():
            param.requires_grad = False
    total_loss=0
    c=0
    weak_anchors_collector=[]
    weight_per_class=None
    worm_up_epoch=50000
    for batch in sup_dataloader:
        optimizer.zero_grad()###zero the gradient
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        #lambda_u=(1-np.exp(-(epoch-worm_up_epoch)/1000))*10
        lambda_u=1
        if epoch>=worm_up_epoch:## warm up
            u_batch=next(iter(unsup_dataloader))
            x_u = u_batch['weak'].to(device).squeeze()
            x_u_augmented = u_batch['strong'].to(device).squeeze()
        
        
        with autocast():
            if epoch>=worm_up_epoch:
            ### unsupervised loss
                with torch.no_grad():
                    output_u = model(x_u)
                    weak_anchors_collector.append(output_u)
                output_u_augmented = model(x_u_augmented)
                loss_u = criteria_unsup(output_u, output_u_augmented)
                
            else:
                loss_u=0
            ### supervised loss
            preds=model(x)
            loss_sup=criteria_sup(preds, labels)
            if epoch>=worm_up_epoch:
                loss=loss_sup+lambda_u*loss_u
            else:
                loss=loss_sup
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
        # logger.add_scalar('norm_1', model.head[0].weight.grad.norm(), c)
        # logger.add_scalar('norm_2', model.backbone.layer1[0].weight.grad.norm(), c)
    return total_loss.item()/c

if __name__=='__main__':
    #make models
    label_fraction_set=[0.01, 0.02, 0.05, 0.1, 0.2, 0.3]
    acc_set=[]
    for label_fraction in label_fraction_set:
        num_class=12
        cnn=CNN(num_class=num_class).cuda()
        transformer_cnn=Transformer_CNN(num_class=num_class).cuda()
        rnn_cnn=RNN_CNN(num_class=num_class).cuda()
        rnn_cnn=load_model(rnn_cnn,name='RNN_CNN_SupCon_iter_7.pt')
        model=SCAN_model(rnn_cnn,num_class).cuda()
        
        #make dataloader
        dataset_name='train_dataset.mat'
        X,Y=load_matfile(dataset_name)  # batch seq feature
        dataset=modudataset(X,Y,transform=none_transform)
        batch_size=64
        train_dataset,test_dataset=split_dataset(dataset,0.2)
        unsup_dataset,sup_dataset=split_dataset(train_dataset,label_fraction)
        unsup_dataset=SelfLabelData(unsup_dataset, none_transform, weak_transform,change_order=True)
        
        sup_dataloader=torch.utils.data.DataLoader(sup_dataset,batch_size=batch_size,shuffle=True,drop_last=True)
        unsup_dataloader=torch.utils.data.DataLoader(unsup_dataset,batch_size=batch_size,shuffle=True,drop_last=True)
        test_dataloader=torch.utils.data.DataLoader(test_dataset,batch_size=batch_size,shuffle=False)
        
        unsup_dataset[1]
        #make optimizer
        optimizer=optim.SGD(model.parameters(),lr=0.1,nesterov=True,momentum=0.9)
        
        #loss functions
        criteria_sup=F.cross_entropy
        from losses import ConfidenceBasedCE,FlexMatchLoss
        criteria_unsup = ConfidenceBasedCE(0.95)
        c=0
        for epoch in range(int(3/label_fraction)+10):
          loss=train_ssl(model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch,update_head_only=True)
          print(loss)
          if loss<=0.005:
              c+=1
          else:
              c=0
          if c>=5:
              break
          if epoch%5==0:
              pred,labels=compute_embeddings(test_dataloader,model.eval(),use_last_layers=True)
              acc=sum(pred.argmax(1)==labels)/len(labels)
              print ('accuracy: {}'.format(acc))
    
        acc_set.append(acc)
