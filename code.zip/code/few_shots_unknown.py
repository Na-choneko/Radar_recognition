import torch
import argparse
from deep_clustering_scan import cluster_acc
from dataset import modudataset,none_transform,weak_transform,TwoCropTransform,train_transform
from utils import get_cluster_metric,compute_embeddings,manifold_features,load_matfile,mine_nearest_neighbors,mine_cluster_centers
from model import CNN,Transformer_CNN,SCAN_model,RNN_CNN
from sklearn.cluster import KMeans
import numpy as np
import torch.optim as optim
import torch.nn.functional as F
from torch.cuda.amp import autocast,GradScaler
device='cuda'
scaler = GradScaler()

def train_on_epoch(model,train_dataloader,optimizer,criteria,update_head_only=True):
    model.train()
    total_loss=0
    c=0
    if update_head_only:
        for param in model.backbone.parameters():
            param.requires_grad = False
    for batch in train_dataloader:
        optimizer.zero_grad()###zero the gradient
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        with autocast():
            preds=model(x)
            loss=criteria(preds, labels)
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
    return total_loss.item()/c

def load_model(model,name='baseline_cnn.pt'):
   model.load_state_dict(torch.load(name))
   return model
def split_balanced(data, target, test_size=0.2):
    np.random.seed(42)
    classes = np.unique(target)
    # can give test_size as fraction of input data size of number of samples
    if test_size<1:
        n_test = np.round(len(target)*test_size)
    else:
        n_test = test_size
    n_train = max(0,len(target)-n_test)
    n_train_per_class = max(1,int(np.floor(n_train/len(classes))))
    n_test_per_class = max(1,int(np.floor(n_test/len(classes))))

    ixs = []
    for cl in classes:
        if (n_train_per_class+n_test_per_class) > np.sum(target==cl):
            # if data has too few samples for this class, do upsampling
            # split the data to training and testing before sampling so data points won't be
            #  shared among training and test data
            splitix = int(np.ceil(n_train_per_class/(n_train_per_class+n_test_per_class)*np.sum(target==cl)))
            ixs.append(np.r_[np.random.choice(np.nonzero(target==cl)[0][:splitix], n_train_per_class),
                np.random.choice(np.nonzero(target==cl)[0][splitix:], n_test_per_class)])
        else:
            ixs.append(np.random.choice(np.nonzero(target==cl)[0], n_train_per_class+n_test_per_class,
                replace=False))

    # take same num of samples from all classes
    ix_train = np.concatenate([x[:n_train_per_class] for x in ixs])
    ix_test = np.concatenate([x[n_train_per_class:(n_train_per_class+n_test_per_class)] for x in ixs])

    X_train = data[ix_train,:]
    X_test = data[ix_test,:]
    y_train = target[ix_train]
    y_test = target[ix_test]

    return X_train, X_test, y_train, y_test
if __name__=='__main__':
    #make models
    num_class=12
    cnn=CNN(num_class=num_class).cuda()
    transformer_cnn=Transformer_CNN(num_class=num_class).cuda()
    scan_model=SCAN_model(transformer_cnn,num_class).cuda()
    rnn_cnn=RNN_CNN(num_class=num_class).cuda()
    
    dataset_name='train_dataset_unkonwn.mat'
    
    #zero-shots classification
    #make dataloader
    X,Y=load_matfile(dataset_name)  # batch seq feature
    dataset=modudataset(X,Y,transform=none_transform)
    batch_size=512
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,shuffle=False)
    
    model_sup=load_model(cnn,name='baseline_cnn_a.pt')
    sup_features,labels=compute_embeddings(dataloader,model_sup.eval())
    
    model_pretext='RNN_CNN_encoder_SimCLR_epoch_399.pt'
    model_p='RNN_CNN_SupCon_iter_7.pt'
    
    model_p=load_model(rnn_cnn,name=model_p)
    features,labels=compute_embeddings(dataloader,model_p.eval(),normalize=True)
    
    model_pretext=load_model(rnn_cnn,name=model_pretext)
    features_pretext,labels=compute_embeddings(dataloader,model_pretext.eval(),normalize=True)
    
    manifold_features(features_pretext,labels,visualize=True)
    
    
    ##clustering
    # kmeans = KMeans(n_clusters=4, n_init=100)
    
    # y_pred = kmeans.fit_predict(features)
    # print ('zero-shots proposed: {}'.format(cluster_acc( y_pred, labels)))
    # print ('P,nmi ,air',get_cluster_metric( y_pred, labels))
    
    # y_pred_pretext = kmeans.fit_predict(features_pretext)
    # print ('zero-shots pretext: {}'.format(cluster_acc( y_pred_pretext, labels)))
    # print ('P,nmi ,air',get_cluster_metric( y_pred_pretext, labels))
    
    # y_pred_sup = kmeans.fit_predict(sup_features)
    # print ('zero-shots sup: {}'.format(cluster_acc( y_pred_sup, labels)))
    # print ('P,nmi, air',get_cluster_metric( y_pred_sup, labels))
    
    #few-shots fine-tune
    
    num_set=[1,5]
    ##### few-shots fine-tune ###########
    acc_set=[]
    for n_per_class in num_set:
        batch_size=32
        X,Y=load_matfile(dataset_name)
        num_class=4
        X_test, X_train, y_test, y_train=split_balanced(X.numpy(), Y.numpy(), num_class*n_per_class)
        dataset_tr=modudataset(torch.from_numpy(X_train),torch.from_numpy(y_train),transform=none_transform)
        dataset_test=modudataset(torch.from_numpy(X_test),torch.from_numpy(y_test),transform=none_transform)
        
        few_shots_dataloader=torch.utils.data.DataLoader(dataset_tr,batch_size=batch_size,shuffle=True)
        test_dataloader=torch.utils.data.DataLoader(dataset_test,batch_size=batch_size,shuffle=False)
        
        sub_contrastive_dataset=modudataset(torch.from_numpy(X_train),torch.from_numpy(y_train),transform=TwoCropTransform(none_transform))
        sup_contrastive_dataloader=torch.utils.data.DataLoader(sub_contrastive_dataset,batch_size=batch_size,pin_memory=True,shuffle=True)
        #make model
        model=SCAN_model(model_sup,num_class).cuda()
        
        # make optimizer and loss
        optimizer=optim.SGD(model.parameters(),lr=0.001,nesterov=True,momentum=0.9)
        criteria=F.cross_entropy
        
        from train_contrastive import train
        from losses import SupConLoss
        from lars import LARS
        from kmeans_supercon import parse_option
        criterion_c=SupConLoss(temperature=1)
        optimizer_c=LARS(model.parameters(),lr=0.5,momentum=0.9)
        opt=parse_option()
        
        for epoch in range(200):
            loss=train_on_epoch(model,few_shots_dataloader,optimizer,criteria,update_head_only=False)
            # for param in model.backbone.parameters():
            #     param.requires_grad = True
            # loss_c=train(sup_contrastive_dataloader, model, criterion_c, optimizer_c, epoch, opt,return_feature=True)
            if epoch%10==0:
                pred,labels=compute_embeddings(test_dataloader,model.eval(),use_last_layers=True)
                acc=sum(pred.argmax(1)==labels)/len(labels)
                print('acc',acc)
                print('loss',loss)
                #print('loss_c',loss_c)
        acc_set.append(acc)




