# -*- coding: utf-8 -*-
"""
Created on Mon Aug  8 15:46:22 2022

@author: 29272
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from MatchboxNet import MatchboxNet,TCSConv

# se-block
class SQE(nn.Module):


    def __init__(self,n_features=5,reduction=1):
        super(SQE, self).__init__()
        self.linear1 = nn.Linear(n_features, n_features // reduction,bias=False)
        self.nonlin1 = nn.LeakyReLU(inplace=True)
        self.linear2 = nn.Linear(n_features // reduction, n_features,bias=False)
        self.nonlin2 = nn.Softmax()
        self.BatchNorm=nn.BatchNorm1d(n_features)

    def forward(self, x):#batch,feature ,seq
        
        y = F.avg_pool1d(x, kernel_size=x.size()[2])
        y = y.permute(0, 2, 1)
        y = self.nonlin1(self.linear1(y))
        y = self.nonlin2(self.linear2(y))
        y = y.permute(0,2,1)
        y = x * y
        y=self.BatchNorm(y)
        return y 

class TCSSQECNN(nn.Module):

    """docstring for ClassName"""
    def __init__(self,input_dim=2,num_class=7,base_size=16):
        super(TCSSQECNN, self).__init__()
        self.layer1 = nn.Sequential(
                        TCSConv(input_dim,base_size,kernel_size=5),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size))
        self.layer2 = nn.Sequential(
                        TCSConv(base_size,base_size*2,kernel_size=5),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*2))
        self.layer3 = nn.Sequential(
                        TCSConv(base_size*2,base_size*4,kernel_size=5),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*4))
        self.layer4 = nn.Sequential(
                        TCSConv(base_size*4,base_size*8,kernel_size=3),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*8))
        self.layer5 = nn.Sequential(
                        TCSConv(base_size*8,base_size*16,kernel_size=3),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*16))
        self.layer6 = nn.Sequential(
                        TCSConv(base_size*16,base_size*32,kernel_size=3),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*32))
        
        self.se1=SQE(base_size,2)
        self.se2=SQE(base_size*2,2)
        self.se3=SQE(base_size*4,2)
        self.se4=SQE(base_size*8,2)
        self.se5=SQE(base_size*16,2)
        self.se6=SQE(base_size*32,2)
        
        self.outputBatchNorm=nn.BatchNorm1d(num_class)
        self.softmax = nn.Softmax()
        
        self.adaptivepool = nn.AdaptiveAvgPool1d(1)
        
        self.proj=nn.Linear(base_size*32,base_size*4) 
        self.out = nn.Linear(base_size*4,num_class)     

    def forward(self,x,return_feature=False):
        out = self.layer1(x)
        out=self.se1(out)
        out = self.layer2(out)
        out=self.se2(out)
        out = self.layer3(out)
        out=self.se3(out)
        out = self.layer4(out)
        out=self.se4(out)
        out = self.layer5(out)
        out=self.se5(out)
        out = self.layer6(out)
        out=self.se6(out)
        out=self.adaptivepool(out)
        out = out.view(out.size(0),-1)
        out = self.proj(out)
        if return_feature:
            return out # 64
        else:
            out = self.out(out)
           # out=out/out.norm(2,dim=1,keepdim=True)
            return out # 64    

class CNN(nn.Module):

    """docstring for ClassName"""
    def __init__(self,input_dim=2,num_class=7,base_size=32,dropout_rate=0):
        super(CNN, self).__init__()
        self.layer1 = nn.Sequential(
                        nn.Conv1d(input_dim,base_size,kernel_size=5,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size))
        self.layer2 = nn.Sequential(
                        nn.Conv1d(base_size,base_size*2,kernel_size=5,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*2))
        self.layer3 = nn.Sequential(
                        nn.Conv1d(base_size*2,base_size*4,kernel_size=5,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*4))
        self.layer4 = nn.Sequential(
                        nn.Conv1d(base_size*4,base_size*8,kernel_size=3,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(4),
                        nn.BatchNorm1d(base_size*8))
        self.layer5 = nn.Sequential(
                        nn.Conv1d(base_size*8,base_size*16,kernel_size=3,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(4),
                        nn.BatchNorm1d(base_size*16))
        self.dropout=nn.Dropout(dropout_rate)
        self.proj=nn.Linear(base_size*128,128) 
        self.out = nn.Linear(128,num_class)  
    def forward(self,x,return_feature=False):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.layer5(out)
        out = self.dropout(out)
        out = out.view(out.size(0),-1)
        out = self.proj(out)
        if return_feature:
            return out # 64
        else:
            out = self.out(out)
           # out=out/out.norm(2,dim=1,keepdim=True)
            return out # 64    

class Transformer_CNN(CNN):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        enc_layer = nn.TransformerEncoderLayer(d_model=256, nhead=8, activation="gelu", dim_feedforward=128, dropout=0)
        self.transformer_enc = nn.TransformerEncoder(enc_layer, num_layers=2, norm=nn.LayerNorm(256))
        self.proj=nn.Linear(256,128) 
        self.out = nn.Linear(128,kwargs['num_class'])
    def forward(self,x,return_feature=False):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out=out.permute(2,0,1)# (batch, feature,seq)--->(seq, batch, feature)
        out=self.transformer_enc(out)# (seq, batch, feature)
        out=out[0]
        out = out.view(out.size(0),-1)
        out = self.proj(out)
        if return_feature:
            return out # 64
        else:
            out = self.out(out)
           # out=out/out.norm(2,dim=1,keepdim=True)
            return out # 64 
        
class RNN_CNN(CNN):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.enc = nn.GRU(input_size=256,hidden_size=128, num_layers=2, bidirectional=True)
        self.proj=nn.Linear(256,128) 
        self.out = nn.Linear(128,kwargs['num_class'])
    def forward(self,x,return_feature=False):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out=out.permute(2,0,1)# (batch, feature,seq)--->(seq, batch, feature)
        out=self.enc(out)# (seq, batch, feature)
        out=out[0][0]
        out = out.view(out.size(0),-1)
        out = self.proj(out)
        if return_feature:
            return out # 64
        else:
            out = self.out(out)
           # out=out/out.norm(2,dim=1,keepdim=True)
            return out # 64     




class CNN_spec(nn.Module):

    """docstring for ClassName"""
    def __init__(self,input_dim=64,num_class=7,base_size=16,dropout_rate=0):
        super(CNN_spec, self).__init__()
        self.layer1 = nn.Sequential(
                        nn.Conv1d(input_dim,base_size,kernel_size=3,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size))
        self.layer2 = nn.Sequential(
                        nn.Conv1d(base_size,base_size*2,kernel_size=3,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*2))
        self.layer3 = nn.Sequential(
                        nn.Conv1d(base_size*2,base_size*4,kernel_size=2,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*4))
        self.layer4 = nn.Sequential(
                        nn.Conv1d(base_size*4,base_size*8,kernel_size=2,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*8))
        self.layer5 = nn.Sequential(
                        nn.Conv1d(base_size*8,base_size*16,kernel_size=2,padding='same'),
                        nn.LeakyReLU(),
                        nn.MaxPool1d(2),
                        nn.BatchNorm1d(base_size*16))
        self.proj=nn.Linear(base_size*32,base_size*16) 
        self.out = nn.Linear(base_size*16,num_class)  
        self.dropout=nn.Dropout(dropout_rate)
    def forward(self,x,return_feature=False):
        out = self.layer1(x)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.layer5(out)
        out = self.dropout(out)
        out = out.view(out.size(0),-1)
        out = self.proj(out)
        if return_feature:
            return out # 64
        else:
            out = self.out(out)
           # out=out/out.norm(2,dim=1,keepdim=True)
            return out # 64   


class LinearClassifier(nn.Module):
    """Linear classifier"""
    def __init__(self, feat_dim=128, num_classes=7):
        super(LinearClassifier, self).__init__()
        self.fc = nn.Linear(feat_dim, num_classes)

    def forward(self, features):
        return self.fc(features)




# autoencoders
class simpleAE(torch.nn.Module):
    def __init__(self):
        super(simpleAE, self).__init__()
        self.encoder = torch.nn.Sequential(
            torch.nn.Linear(64*65, 500),
            torch.nn.ReLU(),
            torch.nn.Linear(500, 500),
            torch.nn.ReLU(),
            torch.nn.Linear(500, 2000),
            torch.nn.ReLU(),
            torch.nn.Linear(2000, 128),
        )
        self.decoder = torch.nn.Sequential(
            torch.nn.Linear(128, 2000),
            torch.nn.ReLU(),
            torch.nn.Linear(2000, 500),
            torch.nn.ReLU(),
            torch.nn.Linear(500, 500),
            torch.nn.ReLU(),
            torch.nn.Linear(500, 64*65),
            torch.nn.Sigmoid()
        )

    def forward(self, x,return_feature=False):
        x = x.view(-1, 64*65)
        z = self.encoder(x)
        recon_x = self.decoder(z)
        if return_feature:
            return z
        else:
            return recon_x


# gans

#info gan
class Generator(nn.Module):
    def __init__(self,opt):
        super(Generator, self).__init__()
        input_dim = opt.latent_dim + opt.n_classes + opt.code_dim

        self.init_size = opt.img_size // 32  # Initial size before upsampling
        self.l1 = nn.Sequential(nn.Linear(input_dim, 128 * self.init_size))

        self.conv_blocks = nn.Sequential(
            nn.BatchNorm1d(128),
            nn.Upsample(scale_factor=2),
            nn.Conv1d(128, 64, 3, padding='same'),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Upsample(scale_factor=2),
            nn.Conv1d(64, 32, 3, padding='same'),
            nn.BatchNorm1d(32),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Upsample(scale_factor=2),
            nn.Conv1d(32, 8, 3, padding='same'),
            nn.BatchNorm1d(8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Upsample(scale_factor=4),
            nn.Conv1d(8, 2, 3, padding='same'),
            nn.Tanh(),
        )

    def forward(self, noise, labels, code):
        gen_input = torch.cat((noise, labels, code), -1)
        out = self.l1(gen_input)
        out = out.view(out.shape[0], 128, self.init_size)
        img = self.conv_blocks(out)/2
        return img


class Discriminator(CNN):
    def __init__(self,opt,base_size=2):
        super(Discriminator, self).__init__(num_class=opt.n_classes,base_size=base_size,dropout_rate=0.5)
        # Output layers
        self.feature_dim=base_size*32
        self.adv_layer = nn.Sequential(nn.Linear(self.feature_dim, 1))
        self.aux_layer = nn.Sequential(nn.Linear(self.feature_dim, opt.n_classes), nn.Softmax())
        self.latent_layer = nn.Sequential(nn.Linear(self.feature_dim, opt.code_dim))

    def forward(self, x,return_feature=False):
        out=super().forward(x,return_feature=True)
        validity = self.adv_layer(out)
        label = self.aux_layer(out)
        latent_code = self.latent_layer(out)
        if return_feature:
            return out
        else:
            return validity, label, latent_code


# SCAN models#
class SCAN_model(torch.nn.Module):
    def __init__(self,encoder,num_classes,hidden_dim=128,head='n_Linear'):
        super().__init__()
        self.backbone=encoder
        if head=='Linear':
            self.head = nn.Linear(hidden_dim, num_classes)
        else:
            self.head = nn.Sequential(
                            nn.Linear(hidden_dim, num_classes*4),
                            nn.LeakyReLU(),
                            nn.Linear(num_classes*4, num_classes))
    def forward(self, x,return_feature=False):
        x = self.backbone(x,return_feature=True)
        if return_feature:
            return x
        else:
            features = self.head(x)
            return features


if __name__=='__main__':
    from torchsummary import summary
    B=3
    R=1
    C=32
    #net=MatchboxNet(B, R, C, kernel_sizes=[11,13,15],inter_feature_dim=32, NUM_CLASSES=7)
    net=CNN()
    inputs = torch.randn(1, 2, 1024)
    outputs = net(inputs)
    summary(net,inputs)