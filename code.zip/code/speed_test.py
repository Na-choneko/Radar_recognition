# -*- coding: utf-8 -*-
"""
test the NN's inference speed
"""
import torch
import time
from model import MatchboxNet,CNN
from torch.cuda.amp import autocast
from torchsummary import summary
B=3
R=1 
C=32
model=MatchboxNet(B, R, C, kernel_sizes=[3,5,7],inter_feature_dim=C, NUM_CLASSES=7).cuda().eval()
#model=CNN().cuda().eval()
batch_size=1024
inputs=torch.rand(batch_size,2,1024).cuda()
start = time.time()
for i in range(100):
   with autocast():
        out=model(inputs)
    

end = time.time()
print ('speed= ',batch_size*100/(end-start))
summary(model,inputs)