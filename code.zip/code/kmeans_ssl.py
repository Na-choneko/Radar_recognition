# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 15:41:46 2022

@author: 29272
"""
from utils import  AverageMeter,compute_embeddings,manifold_features,mine_cluster_centers,load_matfile,match_clusters
from dataset import dataset,modudataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt

from deep_clustering_scan import cluster_acc
import argparse
import torch.optim as optim
import torch.nn.functional as F
from torch.cuda.amp import autocast,GradScaler

from torch.utils.tensorboard import SummaryWriter
logger = SummaryWriter('./log')
device='cuda'
scaler = GradScaler()

def get_params():
    # Training settings
    parser = argparse.ArgumentParser(description='kmeans_ssl')
    parser.add_argument('--lr', type=float, default=2e-4, metavar='LR',
                        help='learning rate (default: 1e-3)')
    parser.add_argument('--T', type=int, default=0.9, metavar='T',
                        help='psudolabel  threshod')
    args, _ = parser.parse_known_args()
    return args

def kmeans_ensemble(kmeans,features):
    num_iter=100
    y_pred_kmeans=np.zeros((num_iter,len(features)))
    #make predictions
    for i in range(num_iter):
        y_pred_kmeans[i,:] = kmeans.fit_predict(features)
    #match clusters
    for i in range(num_iter-1):
        y_pred_kmeans[i+1,:] = match_clusters(y_pred_kmeans[i+1,:],y_pred_kmeans[0,:])
    y_pred_kmeans=y_pred_kmeans.astype(int)
    count=np.apply_along_axis(lambda x: np.bincount(x, minlength=12), axis=0, arr=y_pred_kmeans)
    ensemble_pred=count.argmax(axis=0)
    confidence=count.max(axis=0)/num_iter
    return ensemble_pred,confidence

def train_ssl(model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch,update_head_only=False):
    model.train()
    if update_head_only:
        model.backbone.eval()
    total_loss=0
    c=0
    weak_anchors_collector=[]
    weight_per_class=None
    worm_up_epoch=50
    for batch in sup_dataloader:
        optimizer.zero_grad()###zero the gradient
        x,labels=batch
        x=x.to(device).squeeze()
        labels=labels.to(device).squeeze()
        #lambda_u=(1-np.exp(-(epoch-worm_up_epoch)/1000))*10
        lambda_u=1
        if epoch>=worm_up_epoch:## warm up
            u_batch=next(iter(unsup_dataloader))
            x_u = u_batch['weak'].to(device).squeeze()
            x_u_augmented = u_batch['strong'].to(device).squeeze()
        
        
        with autocast():
            if epoch>=worm_up_epoch:
            ### unsupervised loss
                with torch.no_grad():
                    output_u = model(x_u)
                    weak_anchors_collector.append(output_u)
                output_u_augmented = model(x_u_augmented)
                loss_u,thresholds,target = criteria_unsup(output_u, output_u_augmented,weight_per_class)
                
            else:
                loss_u=0
            ### supervised loss
            preds=model(x)
            loss_sup=criteria_sup(preds, labels)
            if epoch>=worm_up_epoch:
                loss=loss_sup+lambda_u*loss_u
            else:
                loss=loss_sup
        
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        total_loss+=loss
        c=c+1
        # logger.add_scalar('norm_1', model.head[0].weight.grad.norm(), c)
        # logger.add_scalar('norm_2', model.backbone.layer1[0].weight.grad.norm(), c)
    if epoch>=worm_up_epoch:
        weak_anchors_collector=torch.cat(weak_anchors_collector)
        weight_per_class=criteria_unsup.compute_class_weight(weak_anchors_collector)
        # tensorboard logger
        logger.add_scalar('loss_u', loss_u, epoch)
        logger.add_scalar('loss_sup', loss_sup, epoch)
        logger.add_histogram('weight_per_class', weight_per_class, epoch)
        
        # adjust threshod
        current_threshold=criteria_unsup.threshold
        criteria_unsup.threshold=current_threshold+(0.99-current_threshold)/100
        #print(current_threshold)
        # print(target)
    return total_loss.item()/c

def kmeans_ssl_main(args):
    num_class=12
    # model=CNN(num_class=num_class)
    # state_dict=torch.load('CNN_encoder_SimCLR_epoch_1451.pt')
    model=Transformer_CNN(num_class=num_class)
    state_dict=torch.load('Transformer_cnn_encoder_SupCon_epoch_420.pt')
    model.load_state_dict(state_dict)
    model=model.to(device).eval()
    ##compute features
    batch_size=512
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,pin_memory=True,shuffle=False)
    
    features,labels=compute_embeddings(feature_dataloader,model,normalize=True)
    #features=manifold_features(features,labels,n_comp=3,method='umap')
    
    ## kmeans
    kmeans = KMeans(n_clusters=num_class, n_init=100)
    
    y_pred_kmeans = kmeans.fit_predict(features)
    # cluster_centers = Variable((torch.from_numpy(kmeans.cluster_centers_).type(torch.FloatTensor)).cuda(),
    #                            requires_grad=True)
    # y_pred_kmeans,confidence=kmeans_ensemble(kmeans,features)
    # T=0.8
    # print ('confident kmeans accuracy: {}'.format(cluster_acc( y_pred_kmeans[confidence>=T], labels[confidence>=T])))
    
    #GMM
    # from sklearn.mixture import GaussianMixture
    # gm = GaussianMixture(n_components=12)
    # y_pred_kmeans = gm.fit_predict(features)
    print ('Pre-trained kmeans accuracy: {}'.format(cluster_acc( y_pred_kmeans, labels)))
    topk=300
    cluster_centers=kmeans.cluster_centers_
    ind,purity,distances=mine_cluster_centers(features, cluster_centers,topk=topk,labels=labels)
    print (' kmeans nearest_neighbors purity: {}'.format(sum(purity)/len(purity)))
    
    ##### make subdataset using the mined index###########
    X,_=load_matfile('train_dataset.mat')
    labels=[]
    for i in range(num_class):
        labels.append(torch.ones(topk,1)*i)
    Y=torch.cat(labels).long()
    index=ind.flatten()
    u_index=np.setdiff1d(np.arange(0,len(X),1),index)
    X=X[index]
    from dataset import train_transform, none_transform,SelfLabelData,train_transform,weak_transform,base_dataset
    from losses import ConfidenceBasedCE,FlexMatchLoss
    unsup_dataset=torch.utils.data.Subset(base_dataset,u_index)
    unsup_dataset=SelfLabelData(unsup_dataset, weak_transform, train_transform)
    unsup_dataloader=torch.utils.data.DataLoader(unsup_dataset,batch_size=batch_size,shuffle=True)
    criteria_unsup = FlexMatchLoss(args['T'])
    
    sup_dataset=modudataset(X,Y,transform=train_transform)
    sup_dataloader=torch.utils.data.DataLoader(sup_dataset,batch_size=batch_size,shuffle=True)
    criteria_sup=F.cross_entropy
    
    scan_model=SCAN_model(model,12).to(device)
    optimizer=optim.Adam(scan_model.parameters(),lr=args['lr'])
     
    
    for epoch in range(300):
      loss=train_ssl(scan_model,sup_dataloader,unsup_dataloader,optimizer,criteria_sup,criteria_unsup,epoch)
      print(loss)
      if epoch%5==0:
          pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True)
          acc=cluster_acc( pred.argmax(1), labels)
          print ('accuracy: {}'.format(acc))
          logger.add_scalar('acc', acc, epoch)
          print('saving..................')
          torch.save(scan_model.state_dict(),'kmeans_ssl'+'.pt')
      
    pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True)
    print('saving..................')
    torch.save(scan_model.state_dict(),'kmeans_ssl'+'.pt')
    
    return pred,labels



if __name__=='__main__':
    args=vars(get_params())
    pred,labels=kmeans_ssl_main(args)
    print ('accuracy: {}'.format(cluster_acc( pred.argmax(1), labels)))

