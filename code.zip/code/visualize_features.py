import torch
import argparse
from deep_clustering_scan import cluster_acc
from dataset import modudataset,none_transform
from utils import get_cluster_metric,compute_embeddings,manifold_features,load_matfile,mine_nearest_neighbors,mine_cluster_centers
from model import CNN,Transformer_CNN,SCAN_model
from sklearn.cluster import KMeans
def load_model(model,name='baseline_cnn.pt'):
   model.load_state_dict(torch.load(name))
   return model
def visualize(dataset_name):
    #make models
    num_class=12
    cnn=CNN(num_class=num_class).cuda()
    transformer_cnn=Transformer_CNN(num_class=num_class).cuda()
    scan_model=SCAN_model(transformer_cnn,num_class).cuda()
    
    #make dataloader
    X,Y=load_matfile(dataset_name)  # batch seq feature
    dataset=modudataset(X,Y,transform=none_transform)
    batch_size=512
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size,shuffle=False)
    
    ## inference
    
    model_sup_a=load_model(cnn,name='baseline_cnn_a.pt')
    sup_a_features,labels=compute_embeddings(dataloader,model_sup_a.eval())
    
    model_sup=load_model(cnn,name='baseline_cnn.pt')
    sup_features,labels=compute_embeddings(dataloader,model_sup.eval())
    
    model_simclr=load_model(transformer_cnn,name='Transformer_cnn_encoder_SupCon_epoch_420.pt')
    simclr_features,labels=compute_embeddings(dataloader,model_simclr.eval(),normalize=True)
    
    model_scan=load_model(scan_model,name='scan_Transformer_cnn__epoch_29.pt')
    scan_features,labels=compute_embeddings(dataloader,model_scan.eval())
    
    model_kmeans_ssl=load_model(scan_model,name='kmeans_ssl.pt')
    kmeans_ssl_features,labels=compute_embeddings(dataloader,model_kmeans_ssl.eval())
    
    
    # kmeans = KMeans(n_clusters=3, n_init=100)
    # y_pred_kmeans = kmeans.fit_predict(simclr_features)
    # cluster_centers=kmeans.cluster_centers_
    # kmeans_ssl_nearest_purity=[]
    # for topk in range(10,500,50):
    #     ind,purity,distances=mine_cluster_centers(simclr_features,cluster_centers,topk=topk,labels=labels)
    #     kmeans_ssl_nearest_purity.append(sum(purity)/len(purity))
    #     print('nearest_neighbors accuracy:{}'.format(sum(purity)/len(purity)))    
    
    # scan_nearest_purity=[]
    # for topk in range(10,200,10):
    #     indices,acc=mine_nearest_neighbors(simclr_features,topk=topk,labels=labels)
    #     scan_nearest_purity.append(sum(acc)/len(acc))
    #     print('nearest_neighbors accuracy:{}'.format(sum(acc)/len(acc)))
        
    
    
    #visualize
    
    manifold_features(sup_a_features,labels,visualize=True)
    manifold_features(sup_features,labels,visualize=True)
    manifold_features(simclr_features,labels,visualize=True)
    manifold_features(scan_features,labels,visualize=True)
    manifold_features(kmeans_ssl_features,labels,visualize=True)
    return scan_nearest_purity,kmeans_ssl_nearest_purity
    
if __name__=='__main__':
   scan_nearest_purity,kmeans_ssl_nearest_purity=visualize('train_dataset_unkonwn.mat')
    
    