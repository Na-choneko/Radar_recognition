from utils import  AverageMeter,compute_embeddings,manifold_features,mine_nearest_neighbors,mine_cluster_centers
from dataset import dataset,train_dataloader,vali_dataloader,contrastive_dataloader,spec_dataloader,SelfLabelData,train_transform,weak_transform,base_dataset
from model import MatchboxNet,CNN,CNN_spec,Transformer_CNN,SCAN_model
from losses import SupConLoss,ConfidenceBasedCE
from scipy.optimize import linear_sum_assignment as linear_assignment
from sklearn.cluster import KMeans
from sklearn import mixture
import numpy as np
import time
import torch
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from deep_clustering_scan import cluster_acc
from ema import EMA

def get_confidence_acc(preds,labels,T=0.95):
    preds=torch.tensor(preds)
    labels=torch.tensor(labels)
    softmax = torch.nn.Softmax(dim = 1)
    pred_prob = softmax(preds) 
    max_prob, target = torch.max(pred_prob, dim = 1)
    mask = max_prob > T
    target_masked = torch.masked_select(target, mask.squeeze())
    labels_masked = torch.masked_select(labels, mask.squeeze())
    return cluster_acc(target_masked.numpy(),labels_masked.numpy())

def selflabel_train(train_loader, model, criterion, optimizer, epoch, device, ema):
    """ 
    Self-labeling based on confident samples
    """
    model.train()
    start = time.time()
    loss_lst = []
    for i, batch in enumerate(train_loader):
        images = batch['weak'].to(device).squeeze()
        images_augmented = batch['strong'].to(device).squeeze()

        with torch.no_grad():
            model.eval()
            output = model(images)
            model.train()

        output_augmented = model(images_augmented)

        loss = criterion(output, output_augmented)
        loss_lst.append(loss.item())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        

        if ema is not None: # Apply EMA to update the weights of the network
            ema.update_params(model)
            ema.apply_shadow(model)

        if i % (len(train_loader) // 10) == 0:
            now = time.time()
            time_used = int(now - start)
            

    end = time.time()
    time_used = int(end - start)
    print('av_loss:',np.array(loss_lst).mean())
    print('testing')
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=512,pin_memory=True,shuffle=False)
    pred,labels=compute_embeddings(feature_dataloader,model.eval(),use_last_layers=True)
    print ('self-labeling acc: {}'.format(cluster_acc( pred.argmax(axis=1), labels)))



if __name__ == '__main__':
    device='cuda'
    state_dict=torch.load('scan_Transformer_cnn__epoch_19.pt')
    model=Transformer_CNN(num_class=12)
    scan_model=SCAN_model(model,12).to(device)
    scan_model.load_state_dict(state_dict)
    
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=512,pin_memory=True,shuffle=False)
    pred,labels=compute_embeddings(feature_dataloader,scan_model.eval(),use_last_layers=True,normalize=False)    
    get_confidence_acc(pred,labels,0.8)
    ##make datasets#
    sl_dataset =  SelfLabelData(base_dataset, weak_transform, train_transform)
    data_loader = DataLoader(sl_dataset, shuffle=True, batch_size=512)
    criterion = ConfidenceBasedCE(0.9,apply_class_balancing=True)
    ema = EMA(scan_model, alpha=0.99)
    optimizer = torch.optim.SGD(scan_model.parameters(), lr=3e-4, momentum=0.9,weight_decay=0)
    # import copy
    # teacher=copy.deepcopy(scan_model)
    
    for epoch in range(100):
            # Train
        print('Train ...')
        selflabel_train(data_loader, scan_model, criterion, optimizer, epoch, device, ema=None)