# -*- coding: utf-8 -*-
"""
Created on Thu Aug 18 22:01:15 2022

@author: 29272
"""

from dataset import AE_dataset,AE_dataset_test
from model import simpleAE
import torch
import torch.optim as optim
import torch.nn.functional as F
from matplotlib import pyplot as plt
from utils import manifold_features,compute_embeddings
from sklearn.cluster import KMeans
batch_size=128
train_loader=torch.utils.data.DataLoader(AE_dataset,batch_size=batch_size,shuffle=True)
test_loader=torch.utils.data.DataLoader(AE_dataset_test,batch_size=batch_size,shuffle=False)
model=simpleAE().cuda()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
loss_func = torch.nn.BCELoss()
def train(epoch):
    model.train()
    epoch_loss = 0
    for batch_idx, (batch_x, _) in enumerate(train_loader):
        data = batch_x
        X=data[0].cuda().squeeze()
        Y=X
        recon_x = model(X)
        loss = loss_func(recon_x, Y.view(-1, 64*65))
        #print(loss)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        epoch_loss += loss.item()
        # if batch_idx % 100 == 1:
        #     print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss:{:.6f}'.format(
        #         epoch, batch_idx * len(data), len(train_loader.dataset),
        #                100. * batch_idx / len(train_loader),
        #                loss.item() / len(data)
        #     ))

    epoch_loss /= len(train_loader.dataset)
    if epoch %1 == 0:
        print('====> Epoch: {} Average loss: {:.4f}'.format(epoch, epoch_loss))
    return epoch_loss
def AE_main():
    for epoch in range(1, 10):
        train(epoch)
        
    features,labels=compute_embeddings(test_loader,model)
    n2dfeatures=manifold_features(features,labels,n_comp=5)
    manifold_features(features,labels,visualize=True)
         ## kmeans
    kmeans = KMeans(n_clusters=12, n_init=100)
    y_pred_kmeans = kmeans.fit_predict(features)
    y_pred_n2d = kmeans.fit_predict(n2dfeatures)
    return y_pred_kmeans,y_pred_n2d,labels


if __name__ == '__main__':
    y_pred_kmeans,y_pred_n2d,labels=AE_main()
    
    
    
    
    # recon_x=recon_x.view(batch_size,64,65)
    # x=X[0][0]
    # y=X[1][0]
    # c0_tensor=torch.view_as_complex(x.permute(0,2,1).contiguous())
    # spec=torch.stft(c0_tensor,64).abs().squeeze()
    # spec=(spec-spec.min())/(spec.max()-spec.min())
    # plt.figure()
    # plt.imshow(spec)
    # plt.figure()
    # plt.imshow(y.detach().squeeze())

    # torch.save(model.state_dict(), 'pretrain_ae.pkl')