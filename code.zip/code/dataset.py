# -*- coding: utf-8 -*-
"""
Created on Sat Aug  6 17:04:23 2022

@author: 29272
"""

import torch
from torch import nn
from torchvision import datasets, transforms
from torch.utils.data import Dataset
import numpy as np
from scipy import signal
import random
from utils import load_matfile,TwoCropTransform,TwodifferntTransform
from matplotlib import pyplot as plt
from channel import rayleigh_multipath,rayleigh_multipath_fast

##########transforms for data argmentation###########
class signal_transforms():# require the tensor to be [b,s,2]
    def __init__(self,fs=100e6,PRI=1.0240e-05,fc_range=30e6,SNR_range=15,max_cut_ratio=0.6,n_mask=200,device='cpu'):
        self.fs=fs
        self.t=torch.arange(0,PRI,1/fs).to(device)#sampling time
        self.i=torch.complex(torch.tensor(0,dtype=torch.float32),torch.tensor(1,dtype=torch.float32)).to(device)
        self.fc_range=fc_range
        self.snr_range=SNR_range
        self.max_cut_ratio=max_cut_ratio
        self.n_mask = n_mask
        self.channel=rayleigh_multipath_fast(device=device)
        self.device=device
    def normalize(self,tensor):
        out=(tensor.clone()-tensor.min())/(tensor.max()-tensor.min())
        return (out-0.5).clone()# normalize to -0.5 ~ +0.5
    def change_order(self,tensor):# batch seq feature ----> batch feature seq
        out=tensor.clone().permute(0,2,1)
        return self.normalize(out)          
    def random_frequency_off_set(self,tensor):
        '''
        apply random frequency offset to input tensor 

        Parameters
        ----------
        tensor : TYPE
            DESCRIPTION.

        Returns
        -------
        None.

        '''
        tensor_out=tensor.clone()
        
        fc=self.fc_range*torch.rand(1).to(self.device)
        c_tensor=torch.view_as_complex(tensor.contiguous())# batch seq feature ----> batch [complex]               
        c_tensor=c_tensor*torch.exp(self.i*2*torch.pi*fc*self.t).to(self.device)
        #view
        # c=c_tensor[1]
        # plt.plot(torch.fft.fft(c).abs())
        
        tensor_out[:,:,0]=c_tensor.real
        tensor_out[:,:,1]=c_tensor.imag
        return tensor_out
    def add_noise(self,tensor):
        '''
        add noise to the input signal
        '''
        tensor_out=tensor.clone()
        signal_power=tensor.norm(p=2)**2
        noise_power=signal_power/torch.exp((self.snr_range*torch.rand(1)-5)/10).to(self.device)
        noise=torch.randn(tensor.size()).to(self.device)*noise_power/tensor.numel()
        
        return tensor_out+noise
    def frequency_flip(self,tensor):
        tensor_out=tensor.clone()
        c_tensor=torch.view_as_complex(tensor.contiguous())
        tensor_out[:,:,0]=c_tensor.real
        tensor_out[:,:,1]=-c_tensor.imag
        return tensor_out
    def random_cut(self,tensor):
        tensor_out=tensor.clone()
        L=len(self.t)
        idx=int(random.uniform(L-self.max_cut_ratio*L,L))
        tensor_out[:,idx:L,0]=0
        tensor_out[:,idx:L,1]=0
        return tensor_out
    def RandomTimeMasking(self,tensor):
        tensor_out=tensor.clone()
        c_tensor=torch.view_as_complex(tensor.contiguous())
        n_mask=int(self.n_mask*random.uniform(0.5,1.5))
        max_start = tensor.size(1) - n_mask
        idx_rand = random.randint(0, max_start)
        c_tensor[:,idx_rand:idx_rand + n_mask] = torch.randn(n_mask) .to(self.device)* 1e-6
        tensor_out[:,:,0]=c_tensor.real
        tensor_out[:,:,1]=c_tensor.imag
        return tensor_out
    def spectrumgram(self,tensor):
        c_tensor=torch.view_as_complex(tensor.contiguous())
        spectrumgram=torch.stft(c_tensor,64).abs().squeeze()
        return (spectrumgram-spectrumgram.min())/(spectrumgram.max()-spectrumgram.min())
    def Spectrum(self,tensor):
        c_tensor=torch.view_as_complex(tensor.contiguous())
        Spectrum=torch.fft.fft(c_tensor).abs().squeeze()
        return Spectrum
    def Randomresample(self,tensor):####### resample to spread or squeeze spectrum#####
        Spectrum=self.Spectrum(tensor)
        resample_num=int(len(self.t)*random.uniform(0.5,1.5))
        ###down conversion to avoid alising#######
        fd=-Spectrum.argmax()/len(self.t)*self.fs+25e6
        c_tensor=torch.view_as_complex(tensor.contiguous())
        c_tensor=c_tensor*torch.exp(self.i*2*torch.pi*fd*self.t).to(self.device)
        from signaltools import resample
        c_sig=resample(c_tensor,resample_num)
        tensor_out=torch.zeros_like(tensor)
        # c_sig=c_tensor.numpy().transpose(1,0)
        # c_sig=signal.resample(c_sig, resample_num)
        L=c_sig.size()[1]
        L=min(L,len(self.t))
        tensor_out[:,0:L,0]=c_sig.real[:,0:L].unsqueeze(0)
        tensor_out[:,0:L,1]=c_sig.imag[:,0:L].unsqueeze(0)
        return tensor_out## batch seq feature###
    def rayleigh_multipath(self,tensor):
        tensor_out=torch.zeros_like(tensor)
        c_sig=torch.view_as_complex(tensor.contiguous())
        c_sig=self.channel(c_sig)
        tensor_out[:,:,0]=c_sig.real
        tensor_out[:,:,1]=c_sig.imag
        return tensor_out
        


class modudataset(torch.utils.data.TensorDataset):
    """Custom dataset from tensor
    """
    def __init__(self,*args,shuffle=False,transform=None,device='cpu',**kwargs):
        
        super().__init__(*args, **kwargs)
        self.transform=transform
        self.device=device
        if shuffle:
            self.tensors = self.shuffle(self.tensors[0],self.tensors[1])
    def shuffle(self,data,labels):
        '''
        Parameters
        ----------
        data : Tensor/numpy array

        labels : Tensor/numpy array

        Returns
        -------
        data : same as input
            shuffed   data
        labels : same as input
            shuffed   lables

        '''
        num_samples=len(labels)
        idx=np.random.permutation(np.arange(0,num_samples))
        data=data[idx]
        labels=labels[idx]
        return data,labels
    def __getitem__(self, index: int):
        '''
       expect input train data to be : batch seq feature
       return:         batch  feature seq
        '''
        X=self.tensors[0].to(self.device)
        Y=self.tensors[1].to(self.device)
        x=X[index]
        y=Y[index]
        if x.dim()<3:
            x=x.unsqueeze(dim=0)
            y=y.unsqueeze(dim=0)
        try:
            x=self.transform(x)
        except:
            pass
        # c_x=torch.view_as_complex(x.contiguous())
        # c_x=torch.fft.fft(c_x)/max(c_x.abs())
        # x[:,:,0]=c_x.real
        # x[:,:,1]=c_x.imag
        y=y.squeeze()
        return tuple((x,y))
    

## for SCAN #############


class ScanData(Dataset):
    """
    dataset for scan step
    indices: contain all the indices of the nearest neighbors
    """
    def __init__(self, dataset, indices, transform):
        super(ScanData, self).__init__()
        self.data = dataset
        self.indices = indices
        self.transform = transform

    def __getitem__(self, idx):
        out = dict()
        out['anchor'] = self.transform(self.data[idx][0])
        nei_idx = np.random.choice(self.indices[idx], 1)[0]
        out['neighbor'] = self.transform(self.data[nei_idx][0])
        return out

    def __len__(self):
        return self.indices.shape[0]
    

class SelfLabelData(Dataset):
    """
    dataset for selflabel step
    return one weak augmented image and one strong augmented image
    """
    def __init__(self, dataset, weak_T, strong_T,change_order=False):
        super(SelfLabelData, self).__init__()
        self.datas = dataset
        self.weak_T = weak_T
        self.strong_T = strong_T
        self.change_order=change_order
    def __len__(self):
        return len(self.datas)

    def __getitem__(self, idx):
        out = dict()
        image = self.datas[idx][0]
        if self.change_order:
            image=image.permute(0,2,1)
            
        out['weak'] = self.weak_T(image)
        out['strong'] = self.strong_T(image)
        return out

############transforms######################33
device='cpu'
T=signal_transforms(device=device)
train_transform=transforms.Compose([transforms.RandomApply(transforms=[transforms.Lambda(T.Randomresample)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.rayleigh_multipath)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_frequency_off_set)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.frequency_flip)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.RandomTimeMasking)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_cut)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.add_noise)],p=1),
                                   transforms.Lambda(T.change_order)
                                 ])


weak_transform=transforms.Compose([transforms.RandomApply(transforms=[transforms.Lambda(T.random_frequency_off_set)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.frequency_flip)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_cut)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.add_noise)],p=0.5),
                                   transforms.Lambda(T.change_order)
                                 ])

spectrumgram_argue=transforms.Compose([transforms.Lambda(T.normalize),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.Randomresample)],p=0.3),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.rayleigh_multipath)],p=0.3),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_frequency_off_set)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.frequency_flip)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.RandomTimeMasking)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_cut)],p=0.5),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.add_noise)],p=1),
                                   transforms.Lambda(T.spectrumgram)
                                 ])


spectrumgram_transform=transforms.Compose([
                                    transforms.Lambda(T.normalize),
                                    transforms.Lambda(T.spectrumgram)
                                 ])
none_transform=(transforms.Lambda(T.change_order))


show_transform=transforms.Compose([transforms.Lambda(T.normalize),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.Randomresample)],p=0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.rayleigh_multipath)],p=0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_frequency_off_set)],p=0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.frequency_flip)],p=0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.RandomTimeMasking)],p=0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.random_cut)],p=0.0),
                                   transforms.RandomApply(transforms=[transforms.Lambda(T.add_noise)],p=1),
                                   transforms.Lambda(T.spectrumgram)
                                 ])

##############functions####################
def split_dataset(dataset,vali_split=0.1):
    '''
    Parameters
    ----------
    dataset : TYPE
        DESCRIPTION.
    test_split : TYPE, optional
        DESCRIPTION. The default is 0.1.

    Returns
    -------
    train_dataset
    vali_dataset

    '''
    from sklearn.model_selection import train_test_split
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    train_idx, vali_idx = train_test_split(indices,test_size=vali_split)
    assert len(train_idx) != 0 and len(vali_idx) != 0
    train_dataset=torch.utils.data.Subset(dataset,train_idx)
    vali_dataset=torch.utils.data.Subset(dataset,vali_idx)
    return train_dataset,vali_dataset



########make dataset and data loaders#################
X,Y=load_matfile('train_dataset.mat')  # batch seq feature
base_dataset=modudataset(X,Y)
# dataset for baseline eval
base_transform=none_transform
base_line_dataset=modudataset(X,Y,transform=base_transform)
train_dataset,vali_dataset=split_dataset(base_line_dataset)
train_dataset,test_dataset=split_dataset(train_dataset,0.111)


dataset=modudataset(X,Y,transform=none_transform)

contrastive_dataset=modudataset(X,Y,transform=TwoCropTransform(train_transform))
spec_dataset=modudataset(X,Y,transform=spectrumgram_argue)
AE_dataset=modudataset(X,Y,transform=spectrumgram_argue,device=device)
AE_dataset_test=modudataset(X,Y,transform=spectrumgram_transform,device=device)
show_dataset=modudataset(X,Y,transform=TwodifferntTransform(train_transform,none_transform),device=device)





batch_size=512
# dataloader for baseline eval
train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size,shuffle=True)
vali_dataloader=torch.utils.data.DataLoader(vali_dataset, batch_size=batch_size, shuffle=False)
test_dataloader=torch.utils.data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

contrastive_dataloader=torch.utils.data.DataLoader(contrastive_dataset,batch_size=batch_size,shuffle=True)

spec_dataloader=torch.utils.data.DataLoader(spec_dataset,batch_size=batch_size,shuffle=True)

gan_dataloader=torch.utils.data.DataLoader(dataset,batch_size=64,shuffle=True)


if __name__=='__main__':
    # X,Y=show_dataset[110]
    # X0=X[0].squeeze().cpu()
    # X1=X[1].squeeze().cpu()
    # ax1=plt.figure(dpi=1200)
    # a=plt.imshow(X0,extent=[1,10,100,0],aspect=0.1)
    # plt.xlabel('time (us)')
    # plt.ylabel('frequency(MHZ)')
    
    # plt.figure(dpi=1200)
    # b=plt.imshow(X1,extent=[1,10,100,0],aspect=0.1)
    # plt.xlabel('time (us)')
    # plt.ylabel('frequency(MHZ)')
    
    
    X,Y=show_dataset[2110]
    c1_tensor=torch.view_as_complex(X[1].permute(0,2,1).contiguous())
    c0_tensor=torch.view_as_complex(X[0].permute(0,2,1).contiguous())
    plt.figure(dpi=1200)
    plt.plot(c1_tensor.real.squeeze())
    plt.figure(dpi=1200)
    plt.plot(c0_tensor.real.squeeze())