clear all
rng(0);
modTypes = categorical(["LFM",'NLFM','Barker','CostasFM','2FSK','4FSK','T1','T2','T3','T4','LFM-2FSK','LFM-P1']);
addpath 'waveform-types'
i=0;
%% initial channels
fs=100e6;
atenuationset = -20:2:0; % path gain range
delayset = (1:50:1000)*1e-9; % path delay range
atenuations = [0,atenuationset(randperm(length(atenuationset),5))]; % path gains
delays = [0,delayset(randperm(length(delayset),5))]; % path delays
multipathChannel = comm.RayleighChannel(...
    'SampleRate', fs, ...
    'PathDelays', delays, ...
    'AveragePathGains', atenuations, ...
    'MaximumDopplerShift', randi([5 400]));

%%
num_per_type=1000;
for modType = modTypes
    one_type_data = generate_one_type(modType,num_per_type,multipathChannel);
    X(i*num_per_type+1:(i+1)*num_per_type,:,:)=one_type_data;
    Y(i*num_per_type+1:(i+1)*num_per_type,:)=ones(num_per_type,1)*i;
    i=i+1;
end
save('train_dataset.mat','X','Y','-v7.3')
function  data_matrix=generate_one_type(modType,num_samples,multipathChannel)
data_matrix=[];%batch seq feature
for i=1:num_samples  
    sig = helperGeneratewave(modType,10e6*(rand+1),multipathChannel);
    sig=awgn(sig,10*rand+5,'measured');
    I=real(sig);
    Q=imag(sig);
    IQ_sample=[I,Q];%seq feature
    data_matrix(i,:,:)=IQ_sample;
end
end